# Validation report — revision 2

Date: 2026-10-13. Environment: Python 3.12, PyTorch 2.14.1+cpu.
Tests import the edited source tree. CPU threads were limited to one.
No real neural recording or pretrained checkpoint was supplied with the review.

## Automated tests

```bash
OMP_NUM_THREADS=1 MKL_NUM_THREADS=1 python -m pytest \
  tests/test_spectral_pgd.py tests/test_spectral_review.py tests/test_solver.py \
  -q --disable-warnings
```

Final result: **128 passed, 4 skipped**, 3 warnings, in 22.04 seconds.

- Original SVD test file: 74 passed, 1 skipped.
- New review regression file: 46 passed.
- Existing solver regression file: 8 passed, 3 skipped.

The single new skip remains this sandbox's float16 CPU-kernel/cpuinfo
initialization failure. The bfloat16/autocast test passes. The other three skips
are the repository's already-disabled auxiliary-variable tests. Warnings are
from existing package/JIT deprecations. GPU execution was not tested.

New regression coverage includes:

- The review's Poisson 8 x 32 x 10 example, epsilon=2, steps=10, tau=.05,
  both norms/methods and alpha=.01/1. A known valid singleton exists and the
  attack returns a nonzero improving integer perturbation.
- Fallback discovers improvements outside the gradient shortlist, including
  zero/misleading gradients, negative edits and noncontiguous tensors.
- Multi-coordinate groups find a controlled improvement when singletons fail.
- Centered-SVD mean-shift blindness, raw SVD sensitivity, and optional rate bounds.
- Exact rejection denominators, final edit counts, measured drift and compute caps.
- PGD-best vs final PGD: same score/gradient counts, best raw loss at least as high.
- Count/nonnegative/norm/SVD/rate feasibility and direct sklearn count training
  for all four variants, standard and hybrid, with small alpha.
- New options forwarded through clone, fit, save/load, and adaptation.
- Column/neuron permutations separating spectral preservation from temporal
  and covariance/subspace preservation; invalid subspaces explicitly masked.
- Block-Hankel layout, independent calibration quantile calculation, verified
  longer-context insertion and no mutation of input data.
- Within-trial/split window construction and repeatable batch schedules.

Previous tests also cover input-only gradients, restoring BN/dropout modes,
zero budgets, degenerate spectra, finite-difference penalty gradients, invalid
inputs, checkpoint compatibility and clean solver behavior.

## Executed ablation smoke runs

### Fixed tau, two seeds, both norms

```bash
python examples/svd_ablation.py --iterations 2 --seeds 0 1 \
  --taus 0.01 0.05 --norms l2 linf --attack-steps 3 \
  --eval-steps 4 --eval-restarts 2 --loss-budget 16 --gradient-budget 3 \
  --output review_validation/ablation_smoke
```

32 runs completed across ordinary CEBRA, update-matched clean CEBRA, PGD,
PGD-best, gate and guided. The initial model and precomputed batch schedule
match within each seed. Raw CSV/JSON, metadata and train-pair calibration are
included. Maximum SVD rejection rate was approximately 0.807 for gate and
0.683 for guided; permissive settings also produced zero rejections.

### Count edits, raw/centered-rate modes, calibrated tau

```bash
python examples/svd_ablation.py --iterations 1 --seeds 2 --taus 0.05 \
  --norms l2 linf --methods pgd-best gate guided --spectra raw centered-rate \
  --domain counts --epsilon 2 --alpha 0.01 --batch-size 4 --eval-samples 4 \
  --attack-steps 2 --loss-budget 24 --gradient-budget 2 \
  --eval-steps 2 --eval-loss-budget 24 --eval-gradient-budget 2 --calibrate \
  --output review_validation/counts_smoke
```

12 runs completed. Every held-out contrastive attack produced a nonzero
improvement, with 5–9 changed bins across the tested batches. Calibrated tau was
approximately .1920 (raw) / .3744 (centered), and SVD rejection was zero. This
is evidence that calibration can leave SVD inactive at the selected epsilon,
not evidence that these thresholds are scientifically appropriate. The rate
constraint was separately applied in the centered-rate ablation.

The independent evaluation uses a frozen train-only ridge decoder and attacks
held-out prediction MSE without SVD/rate bounds. The count evaluator runs once
because its clean-start search is deterministic; repeating it would not provide
independent random starts. Continuous evaluation uses the requested restarts.
Its objective/evaluation is separate from training but shares the search engine.

All 44 result rows were checked after execution for loss/gradient-budget
compliance, input norm bounds, enabled SVD/rate bounds, and nondecreasing MSE
under the selected independent attack. Modified/new Python files passed syntax
parsing. The revised four-variant usage example also passed this capped count-mode
execution check, producing nonzero loss gains and feasible count edits in all four cases:

```bash
python examples/svd_attacks.py --iterations 1 --domain counts \
  --loss-budget 24 --rate-tau 0.05
```

## Scientific limits

These are **short execution checks**, not evidence of a robustness advantage.
Training has only one or two iterations; some R2 values are negative. Reported
wall times are specific to this shared CPU environment. Equal caps do not mean
equal realized SVD work or wall time. Counter totals cover attack search;
training wall time includes outer updates. Standard uses one optimizer update
per scheduled batch; standard-matched and adversarial methods use two.

No long training, real-recording comparison, GPU benchmark, classification
behavior decoder, physiological validity study, or fully independent attack
implementation was evaluated. The entire repository test suite was not run.
Spectral gradient projection was intentionally deferred per the review.
