# Response to the supplied review — revision 2

The review's central findings were reproduced or encoded as regression tests.
The two original SVD methods and epsilon budgets are retained. This revision
implements the first-stage fixes and analysis utilities, not an unvalidated
replacement of the spectral objective.

| Review item | Resolution | Evidence / limit |
| --- | --- | --- |
| 1. Count truncation and fractional backtracking stall | Replaced with exact signed unit edits, gradient shortlist, increasing multi-edit groups, and remaining-singleton fallback | Poisson 8x32x10 regression at epsilon=2, steps=10, tau=.05; both norms/methods and alpha=.01/1 pass. Misleading/zero-gradient +1 and -1 fallback tests pass. Completeness is local and conditional on an unexhausted budget. |
| 2. Centered SVD ignores mean rate shifts | Added optional hard mean-rate drift bound and guided rate penalty; centered/raw/centered+rate remain separate options | Constant-shift blindness is explicitly tested. Rate constraints are tested in both norms and modes, including count integration. |
| 3. Inactive/overstrict SVD and insufficient logs | Added rejection denominators, activity, unchanged fractions, loss gain, spike/bin edits, effective drift, rate drift, measured work/time and budget flags; train-pair calibration helper | Actual smoke results show both active constraints and permissive calibration with zero SVD rejections. No automatic assertion that quantile calibration is scientifically correct. |
| 4. Last-vs-best confound | Added PGD-best; plain PGD and PGD-best score the same trajectory, with equal evaluation schedules; added global loss/gradient caps | Test verifies equal compute/trajectory schedule and best loss >= final loss. Actual SVD costs remain higher and are reported. |
| 5. Short-window rank limitations | Retained local SVD; added explicit-context longer-window and block-Hankel evaluation helpers | Centered rank ceiling documented; context slice alignment verified. These do not silently extend the encoder receptive field. |
| 6. Spectrum does not imply neural structure | Added covariance, principal-subspace, lag-autocorrelation and firing-rate metrics, plus held-out behavioral decoder evaluation | Column/neuron permutation tests distinguish preserved spectra from temporal/geometric changes. Unidentifiable subspaces are masked instead of assigned arbitrary distances. |
| 7. Spectral gradient projection | Deliberately deferred as a future research variant, per the review's priority | Current penalty-guided objective retained. No claim that a simple clean-point projection solves the zero-gradient issue. |
| 8. Final CEBRA validation | Added controlled multi-seed/tau/norm/spectrum ablation runner, standard and update-matched clean baselines, actual compute/update counts, frozen train-only Ridge decoder and separate decoding-MSE attacks | 44 short synthetic runs completed. Real recordings, long training, GPU runs, and stronger independent implementation checks are not available/claimed. |

## Concrete search guarantees and limits

Without compute caps, when the count shortlist/groups cannot improve the loss,
the fallback examines both signs for every remaining coordinate until an
improving feasible singleton is found. This solves the reported failure to
consider small valid edits after rejecting a large move. It does **not** prove
global optimality or absence of multi-edit improvements. A finite budget or
disabled fallback explicitly removes the local search guarantee.

All count candidates remain integer and nonnegative. They are checked directly
against epsilon and enabled spectral/rate bounds before raw loss evaluation.
Count search no longer uses alpha or continuous projection/truncation.

## Experiment interpretation

The ablation runner uses identical initial model weights and precomputed
behavior-matched batch schedules for a seed. Its sampler is explicit and does
not claim to reproduce sklearn's stochastic loader draw-for-draw. Ordinary
CEBRA uses one update; standard-matched and adversarial methods use two per
scheduled batch. Both baselines are retained, and actual counts are recorded.

The separate decoder evaluation attacks prediction MSE on held-out windows,
without a spectral/rate constraint. It shares the corrected search engine, so
it is a separate objective/evaluation protocol, not an independently written
attack implementation. Neither this evaluation nor unit tests establish a
scientific advantage for SVD.

In the short calibration/count run, raw tau was approximately 0.1920 and centered
tau approximately 0.3744. These settings produced zero SVD rejections, which
shows why activity/rejection logs must accompany calibration. In the fixed-tau
run, stricter settings produced nonzero rejection. The smoke runs have only
one or two training iterations; decoding R2 is sometimes negative and must not
be treated as a trained-model benchmark.

See `SVD_ATTACKS.md`, `SVD_ATTACKS_FA.md`, `TEST_REPORT.md`, and
`review_validation/` for usage, executed checks and raw results.
