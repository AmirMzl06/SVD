"""Offline diagnostics and train-pair calibration, not extra attack constraints."""

import math

import torch

from cebra.solver.spectral_pgd import firing_rate_drift, singular_values, spectral_drift


def _pair(clean, attacked):
    if (not isinstance(clean, torch.Tensor) or not isinstance(attacked, torch.Tensor) or
            clean.shape != attacked.shape or clean.ndim != 3 or min(clean.shape) == 0):
        raise ValueError("Expected equal nonempty (batch, neurons, time) tensors.")
    if clean.device != attacked.device:
        raise ValueError("Both tensors must be on the same device.")
    if not torch.isfinite(clean).all() or not torch.isfinite(attacked).all():
        raise ValueError("Metrics require finite inputs.")
    dtype = torch.float64 if clean.dtype == torch.float64 or attacked.dtype == torch.float64 else torch.float32
    return clean.to(dtype), attacked.to(dtype)


def _eta(eta):
    if not isinstance(eta, (int, float)) or not math.isfinite(eta) or eta <= 0:
        raise ValueError("eta must be finite and positive.")


def block_hankel(windows, delay=3):
    """(B,N,T) -> (B,N*delay,T-delay+1), with each column a delay window."""
    if windows.ndim != 3 or not isinstance(delay, int) or not 1 <= delay <= windows.shape[-1]:
        raise ValueError("delay must be an integer between 1 and the window length.")
    return windows.unfold(-1, delay, 1).permute(0, 1, 3, 2).reshape(
        windows.shape[0], windows.shape[1] * delay, windows.shape[-1] - delay + 1)


@torch.no_grad()
def structure_metrics(clean, attacked, *, subspace_k=3, lag=1, hankel_delay=3, eta=1e-8):
    """Per-reference diagnostics; temporal/behavioral validity is not implied.

    Subspace distance is ||P-P'||_F/sqrt(2*k). It is NaN when either
    truncated subspace is unidentifiable (rank deficiency or a tied cutoff).
    Autocorrelation drift is RMS difference of normalized lag correlations
    across neurons; neurons with zero lag-vector energy use zero correlation.
    """
    _eta(eta)
    clean, attacked = _pair(clean, attacked)
    if clean.shape[-1] < 2:
        raise ValueError("Structure metrics need at least two time bins.")
    if not isinstance(lag, int) or not 1 <= lag < clean.shape[-1]:
        raise ValueError("lag must be between 1 and time-1.")
    if not isinstance(subspace_k, int) or not 1 <= subspace_k <= min(clean.shape[1], clean.shape[2] - 1):
        raise ValueError("subspace_k exceeds the centered window rank ceiling.")
    if not isinstance(hankel_delay, int) or not 1 <= hankel_delay < clean.shape[-1]:
        raise ValueError("hankel_delay must be between 1 and time-1.")
    xc, xa = clean - clean.mean(-1, keepdim=True), attacked - attacked.mean(-1, keepdim=True)
    before, after = singular_values(xc, False), singular_values(xa, False)
    cov = xc @ xc.transpose(-1, -2) / (clean.shape[-1] - 1)
    cov_adv = xa @ xa.transpose(-1, -2) / (clean.shape[-1] - 1)

    def autocorrelation(x):
        a, b = x[..., :-lag], x[..., lag:]
        return (a * b).sum(-1) / ((a.square().sum(-1) * b.square().sum(-1)).sqrt() + eta)

    def subspace(x):
        u, s, _ = torch.linalg.svd(x, full_matrices=False)
        # Avoid reporting arbitrary SVD vectors at repeated singular values.
        tolerance = torch.finfo(x.dtype).eps * max(x.shape[-2:]) * s[:, 0]
        identifiable = s[:, subspace_k - 1] > tolerance
        if subspace_k < s.shape[-1]:
            identifiable &= s[:, subspace_k - 1] - s[:, subspace_k] > tolerance
        basis = u[..., :subspace_k]
        return basis @ basis.transpose(-1, -2), identifiable

    p, valid = subspace(xc)
    pa, valid_adv = subspace(xa)
    valid &= valid_adv
    subspace_distance = (pa - p).flatten(1).norm(dim=1) / math.sqrt(2 * subspace_k)
    subspace_distance = torch.where(valid, subspace_distance,
                                    torch.full_like(subspace_distance, float("nan")))
    hc, ha = block_hankel(clean, hankel_delay), block_hankel(attacked, hankel_delay)
    return dict(
        centered_svd_drift=(after - before).norm(dim=1) / (before.norm(dim=1) + eta),
        raw_svd_drift=spectral_drift(attacked, singular_values(clean, False), False, eta),
        firing_rate_drift=firing_rate_drift(attacked, clean.mean(-1), eta),
        covariance_distance=(cov_adv - cov).flatten(1).norm(dim=1) / (cov.flatten(1).norm(dim=1) + eta),
        principal_subspace_distance=subspace_distance,
        subspace_identifiable=valid,
        autocorrelation_drift=(autocorrelation(xa) - autocorrelation(xc)).square().mean(-1).sqrt(),
        hankel_svd_drift=spectral_drift(ha, singular_values(hc, True), True, eta),
    )


@torch.no_grad()
def context_spectral_drift(clean_window, attacked_window, clean_context, *, start,
                           center=True, eta=1e-8):
    """Insert a local perturbation into an explicitly supplied longer context.

    Contexts must be from the same recording/trial as the clean window. The
    exact slice is verified. This only evaluates longer-window SVD; it neither
    enlarges the encoder's receptive field nor changes its attack constraint.
    """
    _eta(eta)
    clean_window, attacked_window = _pair(clean_window, attacked_window)
    if (clean_context.ndim != 3 or clean_context.shape[:2] != clean_window.shape[:2] or
            clean_context.device != clean_window.device or not torch.isfinite(clean_context).all()):
        raise ValueError("Context must match batch/neuron dimensions, device, and be finite.")
    length = clean_window.shape[-1]
    if not isinstance(start, int) or start < 0 or start + length > clean_context.shape[-1]:
        raise ValueError("Local window does not fit inside the supplied context.")
    if not torch.equal(clean_context[..., start:start + length], clean_window):
        raise ValueError("The context slice does not match the clean reference.")
    context = clean_context.to(clean_window.dtype)
    modified = context.clone()
    modified[..., start:start + length] = attacked_window
    return spectral_drift(modified, singular_values(context, center), center, eta)


@torch.no_grad()
def calibrate_thresholds(train_reference, train_matched, *, quantile=0.95,
                          center=True, eta=1e-8):
    """Quantiles from user-selected pairs of comparable TRAIN-only windows.

    Caller must ensure split/trial boundaries and behavioral comparability.
    This function cannot infer which observations belong to train/test.
    It returns estimates, not a guarantee of physiological or label validity.
    """
    _eta(eta)
    clean, matched = _pair(train_reference, train_matched)
    if len(clean) < 2 or not 0 < quantile <= 1:
        raise ValueError("Need at least two train pairs and quantile in (0,1].")
    if center and clean.shape[-1] < 2:
        raise ValueError("Centered calibration needs at least two time bins.")
    distance = spectral_drift(matched, singular_values(clean, center), center, eta)
    rates = firing_rate_drift(matched, clean.mean(-1), eta)
    return dict(svd_tau=float(torch.quantile(distance, quantile)),
                rate_tau=float(torch.quantile(rates, quantile)),
                quantile=quantile, num_pairs=len(clean), centered=center,
                centered_rank_ceiling=min(clean.shape[1], clean.shape[2] - 1),
                svd_drift_values=distance.cpu().tolist(), rate_drift_values=rates.cpu().tolist())
