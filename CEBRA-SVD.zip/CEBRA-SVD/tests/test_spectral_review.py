"""Regression tests for the issues in the October 2026 review."""

from dataclasses import replace

import numpy as np
import pytest
import torch

from cebra.solver.spectral_pgd import PGDConfig, generate_pgd, singular_values, spectral_drift
from cebra.solver.spectral_metrics import (block_hankel, calibrate_thresholds,
                                          context_spectral_drift, structure_metrics)


@pytest.fixture(autouse=True)
def deterministic():
    threads = torch.get_num_threads()
    torch.set_num_threads(1)
    torch.manual_seed(12)
    yield
    torch.set_num_threads(threads)


@pytest.mark.parametrize("norm", ["l2", "linf"])
@pytest.mark.parametrize("mode", ["gate", "guided"])
@pytest.mark.parametrize("alpha", [0.01, 1.0])
def test_poisson_single_spike_regression(norm, mode, alpha):
    # Review's dimensions/settings; alpha no longer rounds away a unit edit.
    x = torch.poisson(torch.full((8, 32, 10), 4.))
    objective = lambda value: value[0, 0, 0]
    unit = x.clone()
    unit[0, 0, 0] += 1
    distance = spectral_drift(unit, singular_values(x))
    assert distance.max() < 0.05
    cfg = PGDConfig(norm=norm, svd_mode=mode, input_domain="counts", epsilon=2,
                    alpha=alpha, steps=10, svd_tau=0.05, discrete_candidates=2,
                    discrete_max_edits=2)
    result = generate_pgd(x, objective, cfg)
    assert result.loss > result.clean_loss
    assert result.diagnostics["spike_edit_count"] > 0
    assert (result.perturbation_norm <= 2).all()
    assert (result.drift <= 0.05).all()


@pytest.mark.parametrize("norm", ["l2", "linf"])
@pytest.mark.parametrize("mode", ["gate", "guided"])
def test_fallback_finds_edit_hidden_from_gradient_shortlist(norm, mode):
    x = torch.full((1, 2, 3), 3.)
    # Largest gradient suggests harmful finite moves. The only improving unit
    # edit is +1 at the last coordinate, whose clean gradient is exactly zero.
    def objective(value):
        d = (value - x).flatten()
        return 10 * d[0] - 100 * d[:-1].square().sum() + d[-1] ** 3
    cfg = PGDConfig(norm=norm, svd_mode=mode, svd_center=False, svd_tau=1.,
                    input_domain="counts", epsilon=1, steps=1,
                    discrete_candidates=1, discrete_max_edits=1)
    result = generate_pgd(x, objective, cfg)
    assert result.loss == pytest.approx(1.)
    assert result.reference[0, -1, -1] == 4
    assert result.diagnostics["discrete_exhaustive_sweeps"] == 1
    assert result.diagnostics["discrete_incomplete_searches"] == 0
    limited = generate_pgd(x, objective, replace(cfg, discrete_fallback=False))
    assert limited.loss == 0
    assert limited.diagnostics["discrete_incomplete_searches"] == 1


@pytest.mark.parametrize("norm", ["l2", "linf"])
def test_fallback_checks_negative_direction_and_integer_noncontiguous_input(norm):
    x = torch.full((1, 3, 2), 3.).transpose(1, 2)
    def objective(value):
        d = (value - x).reshape(-1)
        return -100 * d[:-1].square().sum() - d[-1] ** 3
    cfg = PGDConfig(norm=norm, svd_mode="gate", svd_center=False, svd_tau=1.,
                    input_domain="counts", epsilon=1, steps=1,
                    discrete_candidates=1, discrete_max_edits=1)
    result = generate_pgd(x, objective, cfg)
    assert result.loss == pytest.approx(1.)
    assert result.diagnostics["spikes_removed"] == 1
    assert result.diagnostics["spikes_added"] == 0


def test_adaptive_multi_edit_can_cross_nonimproving_singletons():
    x = torch.full((1, 1, 3), 5.)
    def objective(value):
        d = (value - x).flatten()
        return d[0] * d[1] - 0.1 * d.square().sum()
    result = generate_pgd(x, objective,
                          PGDConfig(input_domain="counts", epsilon=2, norm="l2",
                                    steps=1, discrete_candidates=1, discrete_max_edits=2))
    assert result.loss > 0
    assert result.diagnostics["spike_edit_count"] == 2


@pytest.mark.parametrize("norm", ["l2", "linf"])
@pytest.mark.parametrize("mode", ["gate", "guided"])
def test_centered_svd_rate_blindness_and_optional_rate_bound(norm, mode):
    x = torch.tensor([[[2., 4., 3., 5.], [3., 1., 4., 2.]]], dtype=torch.float64)
    shifted = x + 0.5
    assert spectral_drift(shifted, singular_values(x)).max() < 1e-12
    assert spectral_drift(shifted, singular_values(x, False), False).max() > 0.05
    cfg = PGDConfig(norm=norm, svd_mode=mode, epsilon=1., alpha=0.15, steps=8,
                    svd_tau=0.1, rate_tau=0.015)
    result = generate_pgd(x, lambda value: value.mean(), cfg)
    assert result.diagnostics["firing_rate_drift_max"] <= 0.015
    assert result.diagnostics["rate_rejection_rate"] > 0
    assert (result.drift <= 0.1).all()


def test_rejection_and_edit_diagnostics_have_measured_denominators():
    x = torch.tensor([[[2., 5., 1., 4.], [1., 3., 2., 4.]]])
    cfg = PGDConfig(norm="linf", svd_mode="gate", epsilon=5., alpha=1., steps=3, svd_tau=0.001)
    result = generate_pgd(x, lambda value: value.square().sum(), cfg)
    d = result.diagnostics
    assert d["svd_rejected_reference_checks"] > 0
    assert d["svd_rejection_rate"] == pytest.approx(d["svd_rejected_reference_checks"] /
                                                   d["svd_candidate_reference_checks"])
    assert d["changed_bin_count"] == int((x != result.reference).sum())
    assert d["attack_loss_gain"] == result.loss - result.clean_loss
    assert d["effective_svd_drift"] == pytest.approx(result.drift.mean())
    assert 0 <= d["svd_active_fraction"] <= 1
    assert d["gradient_evaluations"] <= 3
    assert d["svd_evaluations"] >= 2 * len(x)


@pytest.mark.parametrize("norm", ["l2", "linf"])
def test_pgd_best_uses_same_unconstrained_trajectory_and_compute(norm):
    x = torch.ones(2, 2, 3)
    loss = lambda v: -(v - x - 0.12).square().mean()
    cfg = PGDConfig(norm=norm, epsilon=1., alpha=0.9, steps=5, svd_center=False)
    state = torch.random.get_rng_state()
    last = generate_pgd(x, loss, cfg)
    torch.random.set_rng_state(state)
    best = generate_pgd(x, loss, replace(cfg, best_iterate=True))
    assert best.loss >= last.loss
    assert best.loss >= best.clean_loss
    assert best.loss_evaluations == last.loss_evaluations
    assert best.diagnostics["gradient_evaluations"] == last.diagnostics["gradient_evaluations"]
    assert best.diagnostics["svd_candidate_reference_checks"] == 0
    assert best.diagnostics["svd_rejection_rate"] == 0
    # Baseline spectral drift is measured, no longer a dummy zero tensor.
    torch.testing.assert_close(last.drift, spectral_drift(last.reference, singular_values(x, False), False))


@pytest.mark.parametrize("domain", ["continuous", "counts"])
def test_compute_caps_are_hard_across_epsilon_budgets(domain):
    x = torch.full((2, 2, 3), 3.)
    calls = []
    def objective(value):
        calls.append(1)
        return value.sum()
    cfg = PGDConfig(norm="l2", svd_mode="guided", epsilon=3, steps=10,
                    input_domain=domain, epsilon_factors=(0.5, 1.),
                    svd_center=False, max_loss_evaluations=7, max_gradient_evaluations=2)
    result = generate_pgd(x, objective, cfg)
    assert result.loss_evaluations == len(calls) <= 7
    assert result.diagnostics["gradient_evaluations"] <= 2
    assert result.loss >= result.clean_loss
    assert result.diagnostics["loss_budget_exhausted"] or result.diagnostics["gradient_budget_exhausted"]


def test_best_baseline_supports_budget_scan_and_counts_rate_gate():
    x = torch.full((1, 2, 3), 3.)
    cfg = PGDConfig(best_iterate=True, input_domain="counts", epsilon=2,
                    rate_tau=0.1, epsilon_factors=(0.5, 1.), steps=2)
    result = generate_pgd(x, lambda v: v.sum(), cfg)
    assert result.diagnostics["firing_rate_drift_max"] <= 0.1
    assert result.diagnostics["svd_candidate_reference_checks"] == 0


def test_structure_metrics_detect_information_invisible_to_spectrum():
    x = torch.randn(2, 4, 10, dtype=torch.float64)
    # Column permutation preserves spectrum/covariance/subspace but changes time.
    permuted = x[..., torch.tensor([2, 0, 9, 4, 1, 8, 3, 7, 5, 6])]
    metrics = structure_metrics(x, permuted, subspace_k=2)
    assert metrics["centered_svd_drift"].max() < 1e-12
    assert metrics["covariance_distance"].max() < 1e-12
    assert metrics["principal_subspace_distance"].max() < 1e-12
    assert metrics["autocorrelation_drift"].max() > 0.01
    assert metrics["hankel_svd_drift"].max() > 0.01
    # Neuron rotation/permutation preserves spectrum but changes geometry.
    rotated = x[:, [2, 0, 3, 1], :]
    metrics = structure_metrics(x, rotated, subspace_k=2)
    assert metrics["centered_svd_drift"].max() < 1e-12
    assert metrics["covariance_distance"].max() > 0.01
    assert metrics["principal_subspace_distance"].max() > 0.01


def test_rank_deficient_subspace_and_hankel_layout():
    x = torch.ones(2, 4, 10)
    metrics = structure_metrics(x, x, subspace_k=2)
    assert not metrics["subspace_identifiable"].any()
    assert torch.isnan(metrics["principal_subspace_distance"]).all()
    sequence = torch.tensor([[[1., 2., 3., 4.], [5., 6., 7., 8.]]])
    expected = torch.tensor([[[1., 2., 3.], [2., 3., 4.], [5., 6., 7.], [6., 7., 8.]]])
    torch.testing.assert_close(block_hankel(sequence, 2), expected)


def test_calibration_and_context_use_supplied_pairs_without_modifying_them():
    train = torch.randn(8, 3, 12, dtype=torch.float64)
    paired = train + torch.randn_like(train) * 0.1
    calibration = calibrate_thresholds(train, paired, quantile=0.75)
    independent = spectral_drift(paired, singular_values(train))
    assert calibration["svd_tau"] == pytest.approx(float(torch.quantile(independent, 0.75)))
    assert calibration["num_pairs"] == 8
    assert calibration["centered_rank_ceiling"] == 3
    window, perturbed = train[..., 3:8].clone(), paired[..., 3:8].clone()
    snapshot = train.clone()
    measured = context_spectral_drift(window, perturbed, train, start=3)
    modified = train.clone()
    modified[..., 3:8] = perturbed
    torch.testing.assert_close(measured, spectral_drift(modified, singular_values(train)))
    assert torch.equal(train, snapshot)
    with pytest.raises(ValueError, match="does not match"):
        context_spectral_drift(window + 1, perturbed, train, start=3)


@pytest.mark.parametrize("kwargs", [dict(rate_tau=-1), dict(rate_tau=float("nan")),
                                    dict(discrete_candidates=0), dict(discrete_max_edits=0),
                                    dict(max_loss_evaluations=0), dict(max_gradient_evaluations=1.2),
                                    dict(best_iterate="yes"), dict(discrete_fallback=1)])
def test_new_configuration_validation(kwargs):
    with pytest.raises(ValueError):
        PGDConfig(**kwargs)


@pytest.mark.parametrize("norm", ["l2", "linf"])
@pytest.mark.parametrize("mode", ["gate", "guided"])
@pytest.mark.parametrize("hybrid", [False, True])
def test_counts_sklearn_integration_and_new_option_forwarding(norm, mode, hybrid):
    import cebra
    from sklearn.base import clone
    rng = np.random.default_rng(18)
    x = rng.poisson(4, size=(80, 4)).astype("float32")
    y = rng.normal(size=(80, 2)).astype("float32")
    model = cebra.CEBRA(model_architecture="offset10-model", device="cpu",
                        batch_size=4, max_iterations=1, output_dimension=4,
                        num_hidden_units=8, hybrid=hybrid, training_mode="adversarial",
                        attack_norm=norm, adv_svd_mode=mode, adv_input_domain="counts",
                        adv_epsilon=2., adv_alpha=0.01, adv_steps=2, adv_svd_tau=0.1,
                        adv_best_iterate=True, adv_rate_tau=0.08, adv_rate_weight=2.,
                        adv_discrete_candidates=4, adv_discrete_max_edits=2,
                        adv_discrete_fallback=False, adv_max_loss_evaluations=12,
                        adv_max_gradient_evaluations=1)
    assert clone(model).get_params() == model.get_params()
    model.fit(x, y)
    cfg = model.solver_._pgd_config()
    assert cfg.rate_tau == 0.08 and cfg.rate_weight == 2.
    assert cfg.best_iterate and not cfg.discrete_fallback
    assert cfg.discrete_candidates == 4 and cfg.discrete_max_edits == 2
    assert cfg.max_loss_evaluations == 12 and cfg.max_gradient_evaluations == 1
    stats = model.solver_.last_attack_stats
    assert stats["spike_edit_count"] > 0
    assert stats["adv_norm_max"] <= 2
    assert stats["adv_svd_drift_max"] <= 0.1
    assert stats["firing_rate_drift_max"] <= 0.08
    assert model.solver_.log["optimizer_updates"] == [2]


def test_new_settings_save_load_and_adapt(tmp_path):
    import cebra
    rng = np.random.default_rng(5)
    x, y = rng.normal(size=(70, 4)).astype("float32"), rng.normal(size=(70, 2)).astype("float32")
    model = cebra.CEBRA(model_architecture="offset10-model", device="cpu", batch_size=4,
                        max_iterations=1, max_adapt_iterations=1, output_dimension=4,
                        num_hidden_units=8, training_mode="adversarial", adv_svd_mode="guided",
                        adv_rate_tau=0.2, adv_rate_weight=2., adv_best_iterate=True,
                        adv_discrete_candidates=3, adv_discrete_max_edits=2,
                        adv_discrete_fallback=False, adv_max_loss_evaluations=7,
                        adv_max_gradient_evaluations=1)
    model.fit(x, y)
    expected = model.solver_._attack_settings()
    path = tmp_path / "review.pt"
    model.save(path, backend="sklearn")
    restored = cebra.CEBRA.load(path, backend="sklearn", weights_only=False)
    assert restored.solver_._attack_settings() == expected
    new_x = rng.normal(size=(70, 5)).astype("float32")
    restored.fit(new_x, y, adapt=True)
    assert restored.solver_._attack_settings() == expected


def test_ablation_windows_and_schedule_are_split_trial_safe_and_repeatable():
    import importlib.util
    from pathlib import Path
    path = Path(__file__).parents[1] / "examples/svd_ablation.py"
    spec = importlib.util.spec_from_file_location("svd_ablation_for_test", path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    x = np.arange(60, dtype="float32").reshape(30, 2)
    y = np.arange(30, dtype="float32")[:, None]
    ids = np.repeat([0, 1], 15)
    window, labels, starts = module.windows(x, y, trial_ids=ids)
    assert len(window) == 12
    assert all(np.all(ids[start:start + 10] == ids[start]) for start in starts)
    assert np.array_equal(labels[:, 0], starts + 5)
    first = module.batch_schedule(labels, 3, 4, 7)
    torch.randn(100)
    np.random.seed(99)
    second = module.batch_schedule(labels, 3, 4, 7)
    for a, b in zip(first, second):
        for x, y in zip(a, b):
            np.testing.assert_array_equal(x, y)
