#
# CEBRA: Consistent EmBeddings of high-dimensional Recordings using Auxiliary variables
# © Mackenzie W. Mathis & Steffen Schneider (v0.4.0+)
# Source code:
# https://github.com/AdaptiveMotorControlLab/CEBRA
#
# Please see LICENSE.md for the full license document:
# https://github.com/AdaptiveMotorControlLab/CEBRA/blob/main/LICENSE.md
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
# http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
#
"""This package contains abstract base classes for different solvers.

Solvers are used to package models, criterions and optimizers and implement training
loops. When subclassing abstract solvers, in the simplest case only the
:py:meth:`Solver._inference` needs to be overridden.

For more complex use cases, the :py:meth:`Solver.step` and
:py:meth:`Solver.fit` method can be overridden to
implement larger changes to the training loop.
"""

import abc
import copy
import os
from typing import Callable, Dict, List, Literal, Optional

import literate_dataclasses as dataclasses
# ----------------------------------------------------------------------
# Helpers
# ----------------------------------------------------------------------
import torch

import cebra
import cebra.data
import cebra.io
import cebra.models
from cebra.solver.util import Meter
from cebra.solver.util import ProgressBar


def _l2_normalize(t: torch.Tensor, eps: float = 1e-12):
    """Per-sample L2 normalisation (zero vectors stay zero)."""
    flat = t.reshape(t.size(0), -1)
    norm = flat.norm(p=2, dim=1, keepdim=True).clamp(min=eps)
    return t / norm.view(-1, *([1] * (t.dim() - 1)))


def _rand_radius_like(t: torch.Tensor):
    """U(0,1) radius shaped like t but broadcastable (B,1,1,…) ."""
    return torch.rand([t.size(0)] + [1] * (t.dim() - 1), device=t.device)


def _proj_l2_ball(adv: torch.Tensor, orig: torch.Tensor, epsilon: float):
    """Project adv back to the closed L2 ball of radius ε around orig."""
    delta = adv - orig
    flat = delta.reshape(delta.size(0), -1)
    norm = flat.norm(p=2, dim=1, keepdim=True).clamp(min=1e-12)
    factor = torch.where(norm > epsilon, norm / epsilon, torch.ones_like(norm))
    delta = delta / factor.view(-1, *([1] * (delta.dim() - 1)))
    return orig + delta

def _vat_direction_embedding(
        inference_fn,
        batch: cebra.data.Batch,
        xi: float = 1e-6,
) -> torch.Tensor:
    """
    Compute VAT adversarial direction in INPUT space that maximally changes
    the REFERENCE embedding.

    Returns a unit (per-sample) direction tensor with same shape as batch.reference.
    """

    x = batch.reference

    # Random unit noise (per-sample normalization along last dim)
    d = torch.randn_like(x)
    d = d / (d.norm(dim=-1, keepdim=True) + 1e-8)

    x_pert = (x + xi * d).detach().requires_grad_(True)

    # Clean embedding
    with torch.no_grad():
        out = inference_fn(batch)
        z = out.reference
        z = torch.nn.functional.normalize(z, dim=-1)

    # Perturbed embedding
    pert_batch = cebra.data.Batch(
        reference=x_pert,
        positive=batch.positive,
        negative=batch.negative,
    )

    out_pert = inference_fn(pert_batch)
    z_pert = out_pert.reference
    z_pert = torch.nn.functional.normalize(z_pert, dim=-1)

    # Maximize embedding change (squared L2)
    loss = ((z_pert - z) ** 2).sum(dim=-1).mean()

    (grad_x,) = torch.autograd.grad(loss, x_pert, retain_graph=False, create_graph=False)

    # Unit direction in input space (per-sample)
    r_adv = grad_x / (grad_x.norm(dim=-1, keepdim=True) + 1e-8)
    return r_adv.detach()

#

# positive_perm= shuffle_and_permute(batch.positive)
# anchor_perm= shuffle_and_permute(batch.reference)
# negative_perm= shuffle_and_permute(batch.negative)


# copied_data = copy.deepcopy(batch)#batch.clone().detach()
# copied_data.positive = torch.randn_like(batch.positive).cuda() #positive_perm
# copied_data.reference = torch.randn_like(batch.reference).cuda() #anchor_perm
# copied_data.negative = torch.randn_like(batch.negative).cuda() #negative_perm


# prediction_fix = self._inference(batch)

# prediction_perm= self._inference(copied_data)

# x_perm_ = torch.cat([prediction_perm.reference,prediction_perm.positive, prediction_perm.negative], dim=0)
# x_fix= torch.cat([prediction_fix.reference,prediction_fix.positive, prediction_fix.negative], dim=0)

# self.optimizer.zero_grad()

# cos_raw    = torch.nn.functional.cosine_similarity(x_perm_,x_fix)
# L_cos      = torch.log((2 + cos_raw) / 2).mean()  # log version
# # print(L_cos.item())
# L_cos.backward()
# self.optimizer.step()


# fake_data=torch.randn_like(batch.positive).cuda()


# self.optimizer.zero_grad()

# positive_perm= shuffle_and_permute(batch.positive)
# anchor_perm= shuffle_and_permute(batch.reference)
# fake_data=torch.randn_like(batch.positive).cuda()


# x_perm_ = torch.cat([anchor_perm,positive_perm, batch.negative], dim=0)

# idx = torch.randperm(x_perm_.size(0))[:positive_perm.size(0)]


# permed_data_negative   = x_perm_[idx]

# fake_batch = cebra.data.Batch(
#                 reference=batch.reference,
#                 positive=batch.positive,
#                 negative=batch.negative
#             )
# fake_prediction = self._inference(fake_batch)
# loss, align, uniform= self.criterion(fake_prediction.reference,
#                                       fake_prediction.positive,
#                                       fake_prediction.negative)
# loss.backward()
# self.optimizer.step()


def clone_batch(batch):
    # 1) shallow-copy the Batch container
    new_batch = copy.copy(batch)

    # 2) for each tensor attribute in the batch, clone & detach
    #    adjust this list to match the actual fields in your Batch
    tensor_fields = ['reference', 'positive', 'negative', 'anchor', 'other_tensor']
    for field in tensor_fields:
        tensor = getattr(batch, field, None)
        if isinstance(tensor, torch.Tensor):
            # clone and detach so it shares neither data nor grad
            setattr(new_batch, field, tensor.clone().detach())
        # if the field can be a list/tuple of tensors, you could also do:
        # elif (isinstance(tensor, (list, tuple)) and
        #       all(isinstance(t, torch.Tensor) for t in tensor)):
        #     cloned = [t.clone().detach() for t in tensor]
        #     setattr(new_batch, field, type(tensor)(cloned))

    return new_batch


def shuffle_and_permute(data: torch.Tensor) -> torch.Tensor:
    """
    Shuffle the second (M) and third (D) dimensions of a 3D tensor independently.

    Parameters:
        data (torch.Tensor): Input tensor of shape [N, M, D].

    Returns:
        torch.Tensor: Tensor with shuffled M and D dimensions.
    """
    N, M, D = data.size()

    # Create random permutations for the second and third dimensions
    perm_M = torch.randperm(M)
    # perm_D = torch.randperm(D)

    # Permute the second dimension (axis=1) first, then the third dimension (axis=2)
    shuffled_data = data[:, perm_M.cuda(), :]

    return shuffled_data


@dataclasses.dataclass
class Solver(abc.ABC, cebra.io.HasDevice):
    """Solver base class.

    A solver contains helper methods for bundling a model, criterion and optimizer.

    Attributes:
        model: The encoder for transforming reference, positive and negative samples.
        criterion: The criterion computed from the similarities between positive pairs
            and negative pairs. The criterion can have trainable parameters on its own.
        optimizer: A PyTorch optimizer for updating model and criterion parameters.
        history: Deprecated since 0.0.2. Use :py:attr:`log`.
        decode_history: Deprecated since 0.0.2. Use a hook during training for validation and
            decoding. See the arguments of :py:meth:`fit`.
        log: The logs recorded during training, typically contains the ``total`` loss as well
            as the logs for positive (``pos``) and negative (``neg``) pairs. For the standard
            criterions in CEBRA, also contains the value of the ``temperature``.
        tqdm_on: Use ``tqdm`` for showing a progress bar during training.
        training_mode: The training mode, either "clean" or "adversarial".
        adv_epsilon: The maximum perturbation allowed for adversarial training.
        adv_alpha: The step size for adversarial training.
        adv_aggregate: using aggregated PGD.
        adv_steps: The number of steps for adversarial training.
        attack_norm: The norm used for adversarial training, either "l2" or "linf" or "vat".
        adv_alternate: whether to perturb pos/neg as well as reference
    """

    model: torch.nn.Module
    criterion: torch.nn.Module
    optimizer: torch.optim.Optimizer
    history: List = dataclasses.field(default_factory=list)
    decode_history: List = dataclasses.field(default_factory=list)
    log: Dict = dataclasses.field(default_factory=lambda: ({
        "pos": [],
        "neg": [],
        "total": [],
        "temperature": []
    }))
    tqdm_on: bool = True
    training_mode: str = "clean"
    adv_epsilon: float = 0.05
    adv_aggregate: bool = False
    adv_alpha: float = 0.01
    adv_steps: int = 10
    attack_norm: str = "linf"
    adv_alternate: bool = False
    adv_aggregate: bool = False

    def __post_init__(self):
        cebra.io.HasDevice.__init__(self)
        self.best_loss = float("inf")

    def state_dict(self) -> dict:
        """Return a dictionary fully describing the current solver state.

        Returns:
            State dictionary, including the state dictionary of the models and
            optimizer. Also contains the training history and the CEBRA version
            the model was trained with.
        """

        return {
            "model": self.model.state_dict(),
            "optimizer": self.optimizer.state_dict(),
            "loss": torch.tensor(self.history),
            "decode": self.decode_history,
            "criterion": self.criterion.state_dict(),
            "version": cebra.__version__,
            "log": self.log,
        }

    def load_state_dict(self, state_dict: dict, strict: bool = True):
        """Update the solver state with the given state_dict.

        Args:
            state_dict: Dictionary with parameters for the `model`, `optimizer`,
                and the past loss history for the solver.
            strict: Make sure all states can be loaded. Set to `False` to allow
                to partially load the state for all given keys.
        """

        def _contains(key):
            if key in state_dict:
                return True
            elif strict:
                raise KeyError(
                    f"Key {key} missing in state_dict. Contains: {list(state_dict.keys())}."
                )
            return False

        def _get(key):
            return state_dict.get(key)

        if _contains("model"):
            self.model.load_state_dict(_get("model"))
        if _contains("criterion"):
            self.criterion.load_state_dict(_get("criterion"))
        if _contains("optimizer"):
            self.optimizer.load_state_dict(_get("optimizer"))
        # TODO(stes): This will be deprecated at some point; the "log" attribute
        # holds the same information.
        if _contains("loss"):
            self.history = _get("loss").cpu().numpy().tolist()
        if _contains("decode"):
            self.decode_history = _get("decode")
        if _contains("log"):
            self.log = _get("log")

    @property
    def num_parameters(self) -> int:
        """Total number of parameters in the encoder and criterion."""
        return sum(p.numel() for p in self.parameters())

    def parameters(self):
        """Iterate over all parameters."""
        for parameter in self.model.parameters():
            yield parameter

        for parameter in self.criterion.parameters():
            yield parameter

    def _get_loader(self, loader):
        return ProgressBar(
            loader,
            "tqdm" if self.tqdm_on else "off",
        )

    def fit(
            self,
            loader: cebra.data.Loader,
            valid_loader: cebra.data.Loader = None,
            *,
            save_frequency: int = None,
            valid_frequency: int = None,
            decode: bool = False,
            logdir: str = None,
            save_hook: Callable[[int, "Solver"], None] = None,
    ):
        """Train model for the specified number of steps.

        Args:
            loader: Data loader, which is an iterator over `cebra.data.Batch` instances.
                Each batch contains reference, positive and negative input samples.
            valid_loader: Data loader used for validation of the model.
            save_frequency: If not `None`, the frequency for automatically saving model checkpoints
                to `logdir`.
            valid_frequency: The frequency for running validation on the ``valid_loader`` instance.
            logdir:  The logging directory for writing model checkpoints. The checkpoints
                can be read again using the `solver.load` function, or manually via loading the
                state dict.

        TODO:
            * Refine the API here. Drop the validation entirely, and implement this via a hook?
        """

        self.to(loader.device)

        iterator = self._get_loader(loader)
        self.model.train()
        print(f"ALTERNATE IS {self.adv_alternate}")
        for num_steps, batch in iterator:
            if not self.adv_alternate:
                self.perturbed = 'ref'
            else:
                if num_steps % 3 == 1:
                    self.perturbed = 'pos'
                elif num_steps % 3 == 2:
                    self.perturbed = 'neg'
                else:
                    self.perturbed = 'ref'
            stats = self.step(batch)
            iterator.set_description(stats)

            if save_frequency is None:
                continue
            save_model = num_steps % save_frequency == 0
            run_validation = (valid_loader
                              is not None) and (num_steps % valid_frequency
                                                == 0)
            if run_validation:
                validation_loss = self.validation(valid_loader)
                if self.best_loss is None or validation_loss < self.best_loss:
                    self.best_loss = validation_loss
                    self.save(logdir, "checkpoint_best.pth")
            if save_model:
                if decode:
                    self.decode_history.append(
                        self.decoding(loader, valid_loader))
                if save_hook is not None:
                    save_hook(num_steps, self)
                if logdir is not None:
                    self.save(logdir, f"checkpoint_{num_steps:#07d}.pth")

    def step(self, batch: cebra.data.Batch) -> dict:
        # ------------------------------------------------------------
        # 1) ordinary contrastive update
        # ------------------------------------------------------------
        self.optimizer.zero_grad()

        # ✅ bfloat16 forward pass
        with torch.autocast(device_type=batch.reference.device.type,
                            dtype=torch.bfloat16):
            pred = self._inference(batch)
            loss, align, uniform = self.criterion(
                pred.reference, pred.positive, pred.negative
            )

        loss.backward()
        self.optimizer.step()

        if self.training_mode == "adversarial":
            if self.perturbed == "ref":
                x_base = batch.reference
            elif self.perturbed == "pos":
                x_base = batch.positive
            elif self.perturbed == "neg":
                x_base = batch.negative
            else:
                raise ValueError(f"Unknown perturbed value: {self.perturbed}")

            if self.attack_norm in {"linf", "l2"}:
                self.optimizer.zero_grad()

                adv_epsilon = self.adv_epsilon
                adv_alpha = self.adv_alpha
                adv_steps = self.adv_steps
                adv_aggregate = False
                adv_traj = [] if adv_aggregate else None

                if self.attack_norm == "linf":
                    x_adv = x_base.clone().detach() + torch.empty_like(x_base).uniform_(
                        -adv_epsilon, adv_epsilon
                    )
                    x_adv.requires_grad_(True)
                else:
                    x_adv = x_base.clone().detach()
                    noise = _l2_normalize(torch.randn_like(x_adv))
                    noise *= _rand_radius_like(x_adv) * adv_epsilon
                    x_adv = (x_base + noise).clone().detach().requires_grad_(True)

                for _ in range(adv_steps):
                    if self.attack_norm == "l2" and x_adv.grad is not None:
                        x_adv.grad.zero_()

                    adv_batch = cebra.data.Batch(reference=x_adv if self.perturbed == "ref" else batch.reference,
                                                 positive=x_adv if self.perturbed == "pos" else batch.positive,
                                                 negative=x_adv if self.perturbed == "neg" else batch.negative)
                    with torch.autocast(device_type=x_adv.device.type,
                                        dtype=torch.bfloat16):
                        adv_output = self._inference(adv_batch)
                        adv_loss = self.criterion(adv_output.reference,
                                                  adv_output.positive,
                                                  adv_output.negative)[0]

                    grad_x, = torch.autograd.grad(
                        adv_loss, x_adv,
                        retain_graph=False,
                        create_graph=False
                    )

                    with torch.no_grad():
                        if self.attack_norm == "linf":
                            x_adv = x_adv + adv_alpha * grad_x.sign()
                            x_adv = torch.max(torch.min(x_adv, x_base + adv_epsilon),
                                x_base - adv_epsilon)
                        else:
                            x_adv += adv_alpha * _l2_normalize(grad_x)
                            x_adv = _proj_l2_ball(x_adv, x_base, adv_epsilon)

                        x_adv.requires_grad = True
                        if adv_traj is not None:
                            adv_traj.append(x_adv.detach())
                        

                if adv_traj is None:
                    adv_inputs = [x_adv.detach()]
                    weights = [1.0]
                else:
                    adv_inputs = adv_traj
                    weights = [1.0 / len(adv_inputs) for _ in adv_inputs]
                
                adv_loss_total = 0.0

                for i, x_i in enumerate(adv_inputs):
                    adv_batch = cebra.data.Batch(
                        reference=x_i if self.perturbed == "ref" else batch.reference,
                        positive=x_i if self.perturbed == "pos" else batch.positive,
                        negative=x_i if self.perturbed == "neg" else batch.negative,
                    )

                    # ✅ bfloat16 final adversarial forward
                    with torch.autocast(device_type=x_i.device.type,
                                        dtype=torch.bfloat16):
                        output = self._inference(adv_batch)
                        loss_i, _, _ = self.criterion(
                            output.reference,
                            output.positive,
                            output.negative
                        )

                    adv_loss_total = adv_loss_total + weights[i] * loss_i

                adv_loss_total.backward()
                self.optimizer.step()

        self.history.append(loss.item())
        stats = dict(
            pos=align.item(),
            neg=uniform.item(),
            total=loss.item(),
            temperature=self.criterion.temperature,
        )
        for k, v in stats.items():
            self.log[k].append(v)
        return stats

    # ------------------------------------------------------------
    # 6) logging
    # ------------------------------------------------------------

    def validation(self,
                   loader: cebra.data.Loader,
                   session_id: Optional[int] = None):
        """Compute score of the model on data.

        Args:
            loader: Data loader, which is an iterator over `cebra.data.Batch` instances.
                Each batch contains reference, positive and negative input samples.
            session_id: The session ID, an integer between 0 and the number of sessions in the
                multisession model, set to None for single session.

        Returns:
            Loss averaged over iterations on data batch.
        """
        assert (session_id is None) or (session_id == 0)
        iterator = self._get_loader(loader)
        total_loss = Meter()
        self.model.eval()
        for _, batch in iterator:
            prediction = self._inference(batch)
            loss, _, _ = self.criterion(prediction.reference,
                                        prediction.positive,
                                        prediction.negative)
            total_loss.add(loss.item())
        return total_loss.average

    @torch.no_grad()
    def decoding(self, train_loader, valid_loader):
        """Deprecated since 0.0.2."""
        train_x = self.transform(train_loader.dataset[torch.arange(
            len(train_loader.dataset.neural))])
        train_y = train_loader.dataset.index
        valid_x = self.transform(valid_loader.dataset[torch.arange(
            len(valid_loader.dataset.neural))])
        valid_y = valid_loader.dataset.index
        decode_metric = train_loader.dataset.decode(
            train_x.cpu().numpy(),
            train_y.cpu().numpy(),
            valid_x.cpu().numpy(),
            valid_y.cpu().numpy(),
        )
        return decode_metric

    @torch.no_grad()
    def transform(self, inputs: torch.Tensor) -> torch.Tensor:
        """Compute the embedding.

        This function by default only applies the ``forward`` function
        of the given model, after switching it into eval mode.

        Args:
            inputs: The input signal

        Returns:
            The output embedding.

        TODO:
            * Remove eval mode
        """

        self.model.eval()
        return self.model(inputs)

    @abc.abstractmethod
    def _inference(self, batch: cebra.data.Batch) -> cebra.data.Batch:
        """Given a batch of input examples, return the model outputs.

        TODO: make this a public function?

        Args:
            batch: The input data, not necessarily aligned across the batch
                dimension. This means that ``batch.index`` specifies the map
                between reference/positive samples, if not equal ``None``.

        Returns:
            Processed batch of data. While the input data might not be aligned
            across the sample dimensions, the output data should be aligned and
            ``batch.index`` should be set to ``None``.
        """
        raise NotImplementedError

    def load(self, logdir, filename="checkpoint.pth"):
        """Load the experiment from its checkpoint file.

        Args:
            filename (str): Checkpoint name for loading the experiment.
        """

        savepath = os.path.join(logdir, filename)
        if not os.path.exists(savepath):
            print("Did not find a previous experiment. Starting from scratch.")
            return
        checkpoint = torch.load(savepath, map_location=self.device)
        self.load_state_dict(checkpoint, strict=True)

    def save(self, logdir, filename="checkpoint_last.pth"):
        """Save the model and optimizer params.

        Args:
            logdir: Logging directory for this model.
            filename: Checkpoint name for saving the experiment.
        """
        if not os.path.exists(os.path.dirname(logdir)):
            os.makedirs(logdir)
        savepath = os.path.join(logdir, filename)
        torch.save(
            self.state_dict(),
            savepath,
        )


@dataclasses.dataclass
class MultiobjectiveSolver(Solver):
    """Train models to satisfy multiple learning objectives.

    This variant of the standard :py:class:`cebra.solver.base.Solver` implements multi-objective
    or "hybrid" training.

    Attributes:
        model: A multi-objective CEBRA model
        optimizer: The optimizer used for training.
        num_behavior_features: The feature dimension for the features dedicated
            to satisfy the behavior contrastive objective. The remainder is used
            for time contrastive learning.
        renormalize_features: If ``True``, normalize the behavior and time
            contrastive features individually before computing similarity scores.
    """

    num_behavior_features: int = 3
    renormalize_features: bool = False
    output_mode: Literal["overlapping", "separate"] = "overlapping"

    @property
    def num_time_features(self):
        return self.num_total_features - self.num_behavior_features

    @property
    def num_total_features(self):
        return self.model.num_output

    def __post_init__(self):
        super().__post_init__()
        self._check_dimensions()
        self.model = cebra.models.MultiobjectiveModel(
            self.model,
            dimensions=(self.num_behavior_features, self.model.num_output),
            renormalize=self.renormalize_features,
            output_mode=self.output_mode,
        )

    def _check_dimensions(self):
        """Check the feature dimensions for behavior/time contrastive learning.

        Raises:
            ValueError: If feature dimensions are larger than the model features,
                or not sufficiently large for renormalization.
        """
        if self.output_mode == "separate":
            if self.num_behavior_features >= self.num_total_features:
                raise ValueError(
                    "For multi-objective training, the number of features for "
                    f"behavior contrastive learning ({self.num_behavior_features}) cannot be as large or larger "
                    f"than the total feature dimension ({self.num_total_features})."
                )
            if self.num_time_features >= self.num_total_features:
                raise ValueError(
                    "For multi-objective training, the number of features for "
                    f"time contrastive learning ({self.num_time_features}) cannot be as large or larger "
                    f"than the total feature dimension ({self.num_total_features})."
                )
        if self.renormalize_features:
            if self.num_behavior_features < 2:
                raise ValueError(
                    "When renormalizing the features, the feature dimension needs "
                    "to be at least 2 for behavior. "
                    "Check the values of 'renormalize_features' and 'num_behavior_features'."
                )
            if self.num_time_features < 2:
                raise ValueError(
                    "When renormalizing the features, the feature dimension needs "
                    "to be at least 2 for behavior. "
                    "Check the values of 'renormalize_features' and 'num_time_features'."
                )

    def step(self, batch: cebra.data.Batch) -> dict:
        """Perform a single gradient update with multiple objectives.

        Args:
            batch: The input samples

        Returns:
            Dictionary containing training metrics.
        """
        self.optimizer.zero_grad()
        prediction_behavior, prediction_time = self._inference(batch)

        behavior_loss, behavior_align, behavior_uniform = self.criterion(
            prediction_behavior.reference,
            prediction_behavior.positive,
            prediction_behavior.negative,
        )

        time_loss, time_align, time_uniform = self.criterion(
            prediction_time.reference,
            prediction_time.positive,
            prediction_time.negative,
        )

        loss = behavior_loss + time_loss
        loss.backward()
        self.optimizer.step()
        self.history.append(loss.item())

        # 2) ---------------- adversarial branch (optional) ----------------------
        if self.training_mode == "adversarial":
            if self.attack_norm == "linf":
                adv_eps, adv_alpha, adv_steps = (
                    self.adv_epsilon,
                    self.adv_alpha,
                    self.adv_steps,
                )
                adv_aggregate = False
                adv_traj = [] if adv_aggregate else None

                # Initialize adversarial examples
                x_adv = batch.reference.detach() + torch.empty_like(batch.reference).uniform_(-adv_eps, adv_eps)
                x_adv = x_adv.clamp(0, 1).requires_grad_(True)

                for _ in range(adv_steps):
                    # Compute gradient wrt input only (not model parameters)
                    adv_batch = cebra.data.Batch(
                        reference=x_adv,
                        positive=batch.positive,
                        negative=batch.negative,
                    )

                    adv_pred_beh, adv_pred_time = self._inference(adv_batch)
                    adv_beh_loss, _, _ = self.criterion(
                        adv_pred_beh.reference,
                        adv_pred_beh.positive,
                        adv_pred_beh.negative,
                    )
                    adv_time_loss, _, _ = self.criterion(
                        adv_pred_time.reference,
                        adv_pred_time.positive,
                        adv_pred_time.negative,
                    )
                    adv_loss = adv_beh_loss + adv_time_loss

                    grad_x, = torch.autograd.grad(
                        adv_loss,
                        x_adv,
                        retain_graph=False,
                        create_graph=False,
                    )

                    # PGD update + projection to ε-ball
                    with torch.no_grad():
                        x_adv.add_(adv_alpha * grad_x.sign())
                        x_adv.clamp_(batch.reference - adv_eps, batch.reference + adv_eps)
                        x_adv.requires_grad_(True)
                        if adv_traj is not None:
                            adv_traj.append(x_adv.detach())
                if adv_traj is None:
                    adv_inputs = [x_adv.detach()]
                    weights = [1.0]
                else:
                    adv_inputs = adv_traj
                    weights = [1.0 / len(adv_inputs) for _ in adv_inputs]

                # Final adversarial training step
                self.optimizer.zero_grad()

                adv_loss_total = 0.0

                for i, x_i in enumerate(adv_inputs):
                    adv_batch = cebra.data.Batch(
                        reference=x_i,
                        positive=batch.positive,
                        negative=batch.negative,
                    )
                    adv_pred_beh, adv_pred_time = self._inference(adv_batch)
                    adv_beh_loss, _, _ = self.criterion(
                        adv_pred_beh.reference,
                        adv_pred_beh.positive,
                        adv_pred_beh.negative,
                    )
                    adv_time_loss, _, _ = self.criterion(
                        adv_pred_time.reference,
                        adv_pred_time.positive,
                        adv_pred_time.negative,
                    )
                    adv_loss_total = adv_loss_total + weights[i] * (adv_beh_loss + adv_time_loss)
                adv_loss_total.backward()
                self.optimizer.step()
            elif self.attack_norm == "l2":
                adv_eps, adv_alpha, adv_steps = (
                    self.adv_epsilon,
                    self.adv_alpha,
                    self.adv_steps,
                )
                adv_aggregate = False
                adv_traj = [] if adv_aggregate else None

                x_adv = batch.reference.clone().detach()
                noise = _l2_normalize(torch.randn_like(x_adv))
                noise *= _rand_radius_like(x_adv) * adv_eps
                x_adv = (batch.reference + noise).clone().detach().requires_grad_(True)

                for _ in range(adv_steps):
                    adv_b = cebra.data.Batch(
                        reference=x_adv,
                        positive=batch.positive,
                        negative=batch.negative,
                    )

                    adv_pred_beh, adv_pred_time = self._inference(adv_b)
                    adv_beh_loss, _, _ = self.criterion(
                        adv_pred_beh.reference,
                        adv_pred_beh.positive,
                        adv_pred_beh.negative,
                    )
                    adv_time_loss, _, _ = self.criterion(
                        adv_pred_time.reference,
                        adv_pred_time.positive,
                        adv_pred_time.negative,
                    )
                    adv_loss = adv_beh_loss + adv_time_loss

                    grad_x, = torch.autograd.grad(
                        adv_loss,
                        x_adv,
                        retain_graph=False,
                        create_graph=False,
                    )

                    with torch.no_grad():
                        x_adv += adv_alpha * _l2_normalize(grad_x)
                        x_adv = _proj_l2_ball(x_adv, batch.reference, adv_eps)
                        x_adv.requires_grad_(True)
                        if adv_traj is not None:
                            adv_traj.append(x_adv.detach())
                if adv_traj is None:
                    adv_inputs = [x_adv.detach()]
                    weights = [1.0]
                else:
                    adv_inputs = adv_traj
                    weights = [1.0 / len(adv_inputs) for _ in adv_inputs]

                self.optimizer.zero_grad()

                adv_loss_total = 0.0

                for i, x_i in enumerate(adv_inputs):
                    adv_batch = cebra.data.Batch(
                        reference=x_i,
                        positive=batch.positive,
                        negative=batch.negative,
                    )
                    adv_pred_beh, adv_pred_time = self._inference(adv_batch)
                    adv_beh_loss, _, _ = self.criterion(
                        adv_pred_beh.reference,
                        adv_pred_beh.positive,
                        adv_pred_beh.negative,
                    )
                    adv_time_loss, _, _ = self.criterion(
                        adv_pred_time.reference,
                        adv_pred_time.positive,
                        adv_pred_time.negative,
                    )
                    adv_loss_total = adv_loss_total + weights[i] * (adv_beh_loss + adv_time_loss)
                adv_loss_total.backward()
                self.optimizer.step()
            else:
                raise ValueError(self.attack_norm)

        self.history.append(loss.item())
        return dict(
            behavior_pos=behavior_align.item(),
            behavior_neg=behavior_uniform.item(),
            behavior_total=behavior_loss.item(),
            time_pos=time_align.item(),
            time_neg=time_uniform.item(),
            time_total=time_loss.item(),
        )