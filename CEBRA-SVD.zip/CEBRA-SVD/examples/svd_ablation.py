"""Controlled ablations and independent decoding attacks on continuous labels.

Use --data split_data.npz with X_train, y_train, X_test, y_test, or synthetic
data by default. Optional trial_train/trial_test arrays prevent windows from
crossing trial boundaries. Outputs are research diagnostics, not proof of benefit.
"""

import argparse
import copy
import csv
import hashlib
import json
from pathlib import Path
import time

import numpy as np
from sklearn.linear_model import Ridge
from sklearn.metrics import mean_squared_error, r2_score
import torch

import cebra.data
import cebra.models
import cebra.solver
from cebra.solver.spectral_pgd import PGDConfig, generate_pgd
from cebra.solver.spectral_metrics import calibrate_thresholds, structure_metrics


def windows(x, y, width=10, trial_ids=None):
    """Create within-split/trial windows with labels at their center bin."""
    x, y = np.asarray(x), np.asarray(y)
    if y.ndim == 1:
        y = y[:, None]
    if x.ndim != 2 or y.ndim != 2 or len(x) != len(y) or len(x) < width + 2:
        raise ValueError("Expected X=(time,neurons), y=(time,continuous labels), with >=width+2 rows.")
    if not np.isfinite(x).all() or not np.isfinite(y).all():
        raise ValueError("Input arrays must be finite.")
    tensor = torch.as_tensor(x, dtype=torch.float32).unfold(0, width, 1).contiguous()
    labels = torch.as_tensor(y[width // 2:width // 2 + len(tensor)], dtype=torch.float32)
    starts = np.arange(len(tensor))
    if trial_ids is not None:
        ids = np.asarray(trial_ids)
        if ids.ndim != 1 or len(ids) != len(x):
            raise ValueError("trial IDs must have one value per time bin.")
        keep = np.array([np.all(ids[start:start + width] == ids[start]) for start in starts])
        tensor, labels, starts = tensor[keep], labels[keep], starts[keep]
    if len(tensor) < 3:
        raise ValueError("Too few valid within-trial windows.")
    return tensor, labels, starts


def batch_schedule(labels, steps, batch_size, seed):
    """Precompute paired indices once; attack RNG consumption cannot change data order."""
    rng = np.random.default_rng(seed)
    schedule = []
    for _ in range(steps):
        reference = rng.integers(0, len(labels), batch_size)
        distance = torch.cdist(labels[reference], labels).square()
        distance[torch.arange(batch_size), reference] = float("inf")
        nearby = distance.topk(min(5, len(labels) - 1), largest=False).indices.numpy()
        positive = nearby[np.arange(batch_size), rng.integers(0, nearby.shape[1], batch_size)]
        negative = rng.integers(0, len(labels), batch_size)
        schedule.append((reference, positive, negative))
    return schedule


def encode(model, x, batch_size=256):
    with torch.no_grad():
        return torch.cat([model(x[i:i + batch_size]) for i in range(0, len(x), batch_size)])


def independent_decoding_evaluation(model, train_x, train_y, test_x, test_y, *,
                                    norm, epsilon, domain, steps, restarts, seed,
                                    loss_budget=None, gradient_budget=None):
    """Frozen train-only ridge decoder; held-out MSE attack, no SVD/rate bound.

    This targets behavior prediction directly, independently of the contrastive
    objective used during training. It is still a heuristic white-box attack.
    """
    model.eval()
    train_embedding = encode(model, train_x).cpu().numpy()
    decoder = Ridge(alpha=1.0).fit(train_embedding, train_y.cpu().numpy())
    weight = torch.as_tensor(np.atleast_2d(decoder.coef_), dtype=train_x.dtype, device=train_x.device)
    bias = torch.as_tensor(np.atleast_1d(decoder.intercept_), dtype=train_x.dtype, device=train_x.device)
    def predictions(value):
        return model(value) @ weight.T + bias
    objective = lambda value: (predictions(value) - test_y).square().mean()
    with torch.no_grad():
        clean_prediction = predictions(test_x).cpu().numpy()
        worst_score = float(objective(test_x))
    worst = test_x.clone()
    totals = dict(eval_loss_evaluations=0, eval_gradient_evaluations=0,
                  eval_svd_evaluations=0, eval_attack_seconds=0.)
    # Count search starts at clean and is deterministic; repeating it would
    # inflate compute without providing a genuinely different restart.
    actual_restarts = 1 if domain == "counts" else restarts
    for restart in range(actual_restarts):
        torch.manual_seed(seed + 10000 + restart)
        cfg = PGDConfig(norm=norm, epsilon=epsilon, alpha=epsilon / 4,
                        steps=steps, svd_mode="none", best_iterate=True,
                        input_domain=domain, max_loss_evaluations=loss_budget,
                        max_gradient_evaluations=gradient_budget)
        result = generate_pgd(test_x, objective, cfg)
        totals["eval_loss_evaluations"] += result.loss_evaluations
        totals["eval_gradient_evaluations"] += result.diagnostics["gradient_evaluations"]
        totals["eval_svd_evaluations"] += result.diagnostics["svd_evaluations"]
        totals["eval_attack_seconds"] += result.diagnostics["attack_wall_time_seconds"]
        if result.loss > worst_score:
            worst, worst_score = result.reference, result.loss
    with torch.no_grad():
        robust_prediction = predictions(worst).cpu().numpy()
    truth = test_y.cpu().numpy()
    return dict(clean_decoding_r2=float(r2_score(truth, clean_prediction)),
                robust_decoding_r2=float(r2_score(truth, robust_prediction)),
                clean_decoding_mse=float(mean_squared_error(truth, clean_prediction)),
                robust_decoding_mse=float(mean_squared_error(truth, robust_prediction)),
                eval_restarts=actual_restarts, **totals)


def mean_metrics(clean, attacked):
    metrics = structure_metrics(clean, attacked, subspace_k=min(3, clean.shape[1], clean.shape[2] - 1))
    result = {}
    for name, value in metrics.items():
        finite = value[torch.isfinite(value)]
        result[name] = float(finite.float().mean()) if finite.numel() else None
    return result


def calibrate_from_train(train_x, train_y, starts, seed, center=True):
    rng = np.random.default_rng(seed)
    references = rng.choice(len(train_x), min(128, len(train_x)), replace=False)
    distance = torch.cdist(train_y[references], train_y)
    # Exclude overlapping windows so temporal overlap alone cannot force tau near zero.
    overlap = np.abs(starts[references, None] - starts[None, :]) < train_x.shape[-1]
    distance[torch.as_tensor(overlap)] = float("inf")
    valid = torch.isfinite(distance).any(1)
    references = references[valid.numpy()]
    matches = distance[valid].argmin(1)
    return calibrate_thresholds(train_x[references], train_x[matches], center=center)


def run(args):
    torch.set_num_threads(1)
    if args.data:
        with np.load(args.data, allow_pickle=False) as source:
            arrays = {key: source[key] for key in source.files}
        source_label = "user_split_arrays"
    else:
        rng = np.random.default_rng(2026)
        t = np.linspace(0, 30, 600)
        y = np.stack((np.sin(t), np.cos(t)), axis=1)
        rates = np.exp((y @ rng.normal(size=(2, 8)) * 0.4).clip(-2, 2)) * 4
        x = rng.poisson(rates).astype("float32")
        arrays = dict(X_train=x[:400], y_train=y[:400], X_test=x[400:], y_test=y[400:])
        source_label = "synthetic_poisson_smoke_test"
    train_x, train_y, train_starts = windows(arrays["X_train"], arrays["y_train"],
                                            trial_ids=arrays.get("trial_train"))
    test_x, test_y, _ = windows(arrays["X_test"], arrays["y_test"],
                               trial_ids=arrays.get("trial_test"))
    if train_x.shape[1] != test_x.shape[1] or train_y.shape[1] != test_y.shape[1]:
        raise ValueError("Train and test feature/label dimensions must match.")
    calibration = {
        "centered": calibrate_from_train(train_x, train_y, train_starts, args.seeds[0], True),
        "raw": calibrate_from_train(train_x, train_y, train_starts, args.seeds[0], False),
    }
    output = Path(args.output)
    output.mkdir(parents=True, exist_ok=True)
    (output / "calibration_train_only.json").write_text(json.dumps(calibration, indent=2))
    device = torch.device(args.device)
    train_x, train_y = train_x.to(device), train_y.to(device)
    test_selection = np.random.default_rng(77).choice(len(test_x), min(args.eval_samples, len(test_x)), replace=False)
    test_x, test_y = test_x[test_selection].to(device), test_y[test_selection].to(device)
    rows = []
    schedules = {}
    for seed in args.seeds:
        schedule = batch_schedule(train_y.cpu(), args.iterations, args.batch_size, seed)
        schedule_bytes = b"".join(indices.tobytes() for entry in schedule for indices in entry)
        schedules[str(seed)] = hashlib.sha256(schedule_bytes).hexdigest()
        torch.manual_seed(seed)
        template = cebra.models.init("offset10-model", train_x.shape[1], 8, 4).to(device)
        for norm in args.norms:
            for spectrum in args.spectra:
                calibration_key = "raw" if spectrum == "raw" else "centered"
                taus = [calibration[calibration_key]["svd_tau"]] if args.calibrate else args.taus
                for method in args.methods:
                    tested_taus = taus if method in ("gate", "guided") else [taus[0]]
                    for tau in tested_taus:
                        model = copy.deepcopy(template)
                        criterion = cebra.models.InfoNCE().to(device)
                        optimizer = torch.optim.Adam(model.parameters(), lr=1e-3)
                        adversarial = method not in ("standard", "standard-matched")
                        solver = cebra.solver.SingleSessionSolver(
                            model=model, criterion=criterion, optimizer=optimizer, tqdm_on=False,
                            training_mode="adversarial" if adversarial else "clean",
                            attack_norm=norm, adv_epsilon=args.epsilon, adv_alpha=args.alpha,
                            adv_steps=args.attack_steps,
                            adv_svd_mode=method if method in ("gate", "guided") else "none",
                            adv_best_iterate=method == "pgd-best", adv_svd_tau=tau,
                            adv_svd_center=spectrum != "raw",
                            adv_rate_tau=args.rate_tau if spectrum == "centered-rate" else None,
                            adv_input_domain=args.domain,
                            adv_max_loss_evaluations=args.loss_budget,
                            adv_max_gradient_evaluations=args.gradient_budget,
                        )
                        solver.to(device)
                        logs = []
                        started = time.perf_counter()
                        for step, (ref, pos, neg) in enumerate(schedule):
                            # Reset attack RNG per training step as well as model seed.
                            torch.manual_seed(seed * 10000 + step)
                            batch = cebra.data.Batch(train_x[ref], train_x[pos], train_x[neg])
                            logs.append(solver.step(batch))
                            if method == "standard-matched":
                                logs.append(solver.step(batch))
                        if device.type == "cuda":
                            torch.cuda.synchronize(device)
                        training_seconds = time.perf_counter() - started
                        # Fixed held-out reference batch for contrastive/structural diagnostics.
                        evaluation_batch = cebra.data.Batch(test_x, test_x.roll(1, 0), test_x.flip(0))
                        torch.manual_seed(seed + 5000)
                        if adversarial:
                            attacked = solver._generate_adversarial_reference(evaluation_batch)
                            attack_metrics = solver.last_attack_stats.copy()
                        else:
                            attacked, attack_metrics = test_x, {}
                        metrics = mean_metrics(test_x, attacked)
                        independent = independent_decoding_evaluation(
                            model, train_x, train_y, test_x, test_y, norm=norm,
                            epsilon=args.epsilon, domain=args.domain, steps=args.eval_steps,
                            restarts=args.eval_restarts, seed=seed,
                            loss_budget=args.eval_loss_budget, gradient_budget=args.eval_gradient_budget)
                        row = dict(seed=seed, method=method, norm=norm, spectrum=spectrum,
                                   tau=tau if method in ("gate", "guided") else None,
                                   rate_tau=args.rate_tau if spectrum == "centered-rate" else None,
                                   source=source_label, optimizer_updates=sum(log["optimizer_updates"] for log in logs),
                                   train_loss_evaluations=sum(log.get("adv_loss_evaluations", 0) for log in logs),
                                   train_gradient_evaluations=sum(log.get("gradient_evaluations", 0) for log in logs),
                                   train_svd_evaluations=sum(log.get("svd_evaluations", 0) for log in logs),
                                   training_seconds=training_seconds, **attack_metrics, **metrics, **independent)
                        rows.append(row)
                        print(f"seed={seed} {method} {norm} {spectrum} tau={row['tau']} "
                              f"updates={row['optimizer_updates']} clean_R2={row['clean_decoding_r2']:.4f} "
                              f"robust_R2={row['robust_decoding_r2']:.4f}", flush=True)
                        # Checkpoint research output after each experiment, not only at the end.
                        (output / "results.json").write_text(json.dumps(rows, indent=2, allow_nan=False))
    fields = sorted({key for row in rows for key in row})
    with (output / "results.csv").open("w", newline="") as stream:
        writer = csv.DictWriter(stream, fieldnames=fields)
        writer.writeheader()
        writer.writerows(rows)
    metadata = dict(arguments=vars(args), torch_version=torch.__version__,
                    source=source_label, schedule_sha256_by_seed=schedules,
                    evaluation="held-out fixed ridge decoder MSE attack, no SVD/rate bound",
                    sampling="fixed nearest-behavior positive batches; not sklearn's stochastic loader",
                    claims="execution/ablation framework only; no evidence of scientific superiority")
    (output / "run_metadata.json").write_text(json.dumps(metadata, indent=2))
    return rows


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--data", help="NPZ with explicit train/test splits and continuous labels")
    parser.add_argument("--output", default="ablation_results")
    parser.add_argument("--device", default="cpu")
    parser.add_argument("--iterations", type=int, default=20)
    parser.add_argument("--batch-size", type=int, default=8)
    parser.add_argument("--seeds", nargs="+", type=int, default=[0, 1, 2])
    parser.add_argument("--taus", nargs="+", type=float, default=[0.01, 0.05])
    parser.add_argument("--norms", nargs="+", choices=["l2", "linf"], default=["l2", "linf"])
    parser.add_argument("--spectra", nargs="+", choices=["centered", "raw", "centered-rate"], default=["centered"])
    parser.add_argument("--methods", nargs="+", choices=["standard", "standard-matched", "pgd", "pgd-best", "gate", "guided"],
                        default=["standard", "standard-matched", "pgd", "pgd-best", "gate", "guided"])
    parser.add_argument("--epsilon", type=float, default=0.5)
    parser.add_argument("--alpha", type=float, default=0.1)
    parser.add_argument("--rate-tau", type=float, default=0.05)
    parser.add_argument("--domain", choices=["continuous", "nonnegative", "counts"], default="continuous")
    parser.add_argument("--attack-steps", type=int, default=5)
    parser.add_argument("--loss-budget", type=int)
    parser.add_argument("--gradient-budget", type=int)
    parser.add_argument("--eval-samples", type=int, default=16)
    parser.add_argument("--eval-steps", type=int, default=10)
    parser.add_argument("--eval-restarts", type=int, default=2)
    parser.add_argument("--eval-loss-budget", type=int)
    parser.add_argument("--eval-gradient-budget", type=int)
    parser.add_argument("--calibrate", action="store_true", help="Use the TRAIN-pair 95th percentile as tau")
    args = parser.parse_args()
    for name in ("iterations", "batch_size", "attack_steps", "eval_steps", "eval_restarts"):
        if getattr(args, name) < 1:
            parser.error(f"--{name.replace('_', '-')} must be positive.")
    if args.eval_samples < 2:
        parser.error("--eval-samples must be at least two for R2.")
    run(args)


if __name__ == "__main__":
    main()
