"""Feasibility, objective, gradient, and training integration regressions."""

import copy
from dataclasses import replace

import numpy as np
import pytest
import torch
from sklearn.base import clone

import cebra
import cebra.models
from cebra.solver.spectral_pgd import PGDConfig, generate_pgd, singular_values


@pytest.fixture(autouse=True)
def reproducible_cpu():
    threads = torch.get_num_threads()
    torch.set_num_threads(1)
    torch.manual_seed(41)
    yield
    torch.set_num_threads(threads)


def measured_drift(original, attacked, center=True, eta=1e-8):
    if center:
        original = original - original.mean(-1, keepdim=True)
        attacked = attacked - attacked.mean(-1, keepdim=True)
    before, after = torch.linalg.svdvals(original), torch.linalg.svdvals(attacked)
    return (after - before).norm(dim=1) / (before.norm(dim=1) + eta)


@pytest.mark.parametrize("mode", ["gate", "guided"])
@pytest.mark.parametrize("norm", ["l2", "linf"])
@pytest.mark.parametrize("center", [True, False])
def test_per_reference_budget_and_spectral_bound(mode, norm, center):
    original = torch.randn(6, 4, 7, dtype=torch.float64)
    original[0] *= 0.05  # A batch mean must not conceal this sensitive reference.
    snapshot = original.clone()
    target = torch.randn_like(original)
    objective = lambda x: (x * target).sum() / len(x)
    cfg = PGDConfig(norm=norm, svd_mode=mode, svd_center=center,
                    epsilon=0.7, alpha=0.3, steps=6, svd_tau=0.02,
                    epsilon_factors=(0.25, 0.5, 1.0))
    result = generate_pgd(original, objective, cfg)
    actual = result.reference
    flat = (actual - original).flatten(1)
    magnitude = flat.norm(dim=1) if norm == "l2" else flat.abs().amax(1)
    assert (magnitude <= cfg.epsilon + 1e-12).all()
    assert (magnitude <= result.epsilon + 1e-12).all()
    assert (measured_drift(original, actual, center) <= cfg.svd_tau).all()
    assert result.loss >= result.clean_loss
    assert result.loss == pytest.approx(float(objective(actual)))
    assert torch.equal(original, snapshot)
    assert not actual.requires_grad
    assert result.epsilon in (0.0, 0.175, 0.35, 0.7)


@pytest.mark.parametrize("norm", ["l2", "linf"])
def test_attack_has_nonzero_effect_and_guidance_changes_search(norm):
    x = torch.tensor([[[3., 0., -1.], [0., 2., -2.]]], dtype=torch.float64)
    objective = lambda value: value.square().mean()
    cfg = PGDConfig(norm=norm, svd_mode="gate", svd_center=False,
                    epsilon=1.0, alpha=0.1, steps=5, svd_tau=1.0)
    state = torch.random.get_rng_state()
    gate = generate_pgd(x, objective, cfg)
    torch.random.set_rng_state(state)
    zero_weight = generate_pgd(x, objective, replace(cfg, svd_mode="guided", svd_weight=0))
    torch.random.set_rng_state(state)
    guided = generate_pgd(x, objective, replace(cfg, svd_mode="guided", svd_weight=1000))
    assert gate.loss > gate.clean_loss
    assert torch.equal(gate.reference, zero_weight.reference)
    assert not torch.allclose(gate.reference, guided.reference)
    assert guided.drift.max() < gate.drift.max()


@pytest.mark.parametrize("mode", ["none", "gate", "guided"])
@pytest.mark.parametrize("norm", ["l2", "linf"])
@pytest.mark.parametrize("setting", [dict(epsilon=0), dict(steps=0)])
def test_zero_budget_or_steps_returns_clean(mode, norm, setting):
    x = torch.randn(3, 2, 4)
    result = generate_pgd(x, lambda v: v.square().mean(), PGDConfig(norm=norm, svd_mode=mode, **setting))
    assert torch.equal(result.reference, x)
    assert result.epsilon == 0


@pytest.mark.parametrize("mode", ["gate", "guided"])
@pytest.mark.parametrize("norm", ["l2", "linf"])
def test_integer_nonnegative_and_spectral_constraints(mode, norm):
    x = torch.tensor([[[2., 0., 3., 1.], [0., 4., 0., 2.]],
                      [[0., 1., 0., 0.], [2., 0., 0., 0.]]])
    cfg = PGDConfig(norm=norm, svd_mode=mode, input_domain="counts", epsilon=4,
                    alpha=2, steps=5, svd_tau=0.2, svd_center=False)
    result = generate_pgd(x, lambda v: (v * torch.arange(4)).sum(), cfg)
    assert (result.reference >= 0).all()
    assert torch.equal(result.reference, result.reference.round())
    assert (result.perturbation_norm <= 4 + 1e-6).all()
    assert (measured_drift(x, result.reference, False) <= 0.2).all()


@pytest.mark.parametrize("norm", ["l2", "linf"])
def test_subunit_count_budget_and_nonnegative_domain(norm):
    x = torch.tensor([[[0., 2., 1.], [1., 0., 0.]]])
    cfg = PGDConfig(norm=norm, svd_mode="guided", input_domain="counts", epsilon=0.99)
    result = generate_pgd(x, lambda v: -v.sum(), cfg)
    assert torch.equal(x, result.reference)
    result = generate_pgd(x, lambda v: -v.sum(), replace(cfg, input_domain="nonnegative"))
    assert (result.reference >= 0).all()
    assert (result.perturbation_norm <= cfg.epsilon + 1e-6).all()


@pytest.mark.parametrize("kind", ["zero", "constant", "repeated", "rank_deficient"])
def test_degenerate_spectra_are_finite(kind):
    x = {"zero": torch.zeros(2, 3, 5), "constant": torch.ones(2, 3, 5),
         "repeated": torch.eye(3).repeat(2, 1, 1),
         "rank_deficient": torch.arange(5.).repeat(2, 3, 1)}[kind]
    result = generate_pgd(x, lambda v: v.square().mean() + v.mean(),
                          PGDConfig(svd_mode="guided", svd_tau=0))
    assert torch.isfinite(result.reference).all()
    assert torch.isfinite(result.drift).all()
    assert (result.drift == 0).all()


def test_penalty_autograd_finite_difference():
    x = torch.randn(2, 3, 5, dtype=torch.float64)
    anchor = singular_values(x).detach()
    perturbed = (x + torch.randn_like(x) * 0.03).requires_grad_()
    def penalty(value):
        # The exact penalty differentiated by the guided optimizer.
        from cebra.solver.spectral_pgd import spectral_drift
        return spectral_drift(value, anchor).square().mean()
    assert torch.autograd.gradcheck(penalty, perturbed, atol=1e-5)


@pytest.mark.parametrize("dtype", [torch.float16, torch.bfloat16])
def test_svd_promotes_low_precision(dtype):
    try:
        x = torch.randn(2, 3, 5).to(dtype).requires_grad_()
        with torch.autocast("cpu", dtype=torch.bfloat16):
            values = singular_values(x)
        assert values.dtype == torch.float32
        values.sum().backward()
        assert torch.isfinite(x.grad).all()
    except RuntimeError as error:
        if "Failed to initialize cpuinfo" in str(error):
            pytest.skip("This CPU sandbox cannot initialize PyTorch's half-precision kernels.")
        raise


@pytest.mark.parametrize("kwargs", [
    dict(norm="l1"), dict(svd_mode="bad"), dict(epsilon=-1),
    dict(alpha=float("nan")), dict(svd_tau=float("inf")), dict(svd_eta=0),
    dict(steps=-1), dict(backtracks=1.5), dict(svd_weight=-1),
    dict(input_domain="bad"), dict(epsilon_factors=()),
    dict(epsilon_factors=(0.5, 0.3)), dict(epsilon_factors=(0, 1)),
    dict(epsilon_factors=(1.1,)), dict(epsilon_factors=(0.5, 1)),
])
def test_invalid_configuration(kwargs):
    with pytest.raises(ValueError):
        PGDConfig(**kwargs)


def test_reference_validation():
    cfg = PGDConfig(svd_mode="gate")
    with pytest.raises(ValueError, match="two time bins"):
        generate_pgd(torch.ones(2, 4, 1), lambda v: v.sum(), cfg)
    result = generate_pgd(torch.ones(2, 4, 1), lambda v: v.sum(), replace(cfg, svd_center=False))
    assert result.reference.shape == (2, 4, 1)
    for x in [torch.ones(2, 3), torch.ones(2, 3, 4, dtype=torch.int64),
              torch.full((2, 3, 4), float("nan")), torch.empty(0, 2, 3)]:
        with pytest.raises(ValueError):
            cfg.validate_reference(x)
    with pytest.raises(ValueError, match="integer-valued"):
        replace(cfg, input_domain="counts").validate_reference(torch.full((2, 3, 4), 0.5))
    with pytest.raises(ValueError, match="nonnegative"):
        replace(cfg, input_domain="nonnegative").validate_reference(-torch.ones(2, 3, 4))


def make_solver(norm, mode, hybrid=False, batchnorm=False):
    if hybrid:
        model = cebra.models.init("offset10-model", 4, 8, 4)
        solver_class = cebra.solver.SingleSessionHybridSolver
    else:
        model = torch.nn.Sequential(torch.nn.Conv1d(4, 4, 10),
                                    torch.nn.BatchNorm1d(4) if batchnorm else torch.nn.Identity(),
                                    torch.nn.Flatten(1))
        solver_class = cebra.solver.SingleSessionSolver
    criterion = cebra.models.InfoNCE()
    optimizer = torch.optim.Adam(model.parameters(), lr=0.001)
    solver = solver_class(model=model, criterion=criterion, optimizer=optimizer,
                          training_mode="adversarial", attack_norm=norm,
                          adv_svd_mode=mode, adv_steps=2, adv_svd_tau=0.05,
                          adv_epsilon_factors=(0.5, 1.) if mode != "none" else (1.,),
                          tqdm_on=False)
    batch = cebra.data.Batch(torch.randn(8, 4, 10),
                             torch.randn(16 if hybrid else 8, 4, 10), torch.randn(8, 4, 10))
    return solver, batch


@pytest.mark.parametrize("norm", ["l2", "linf"])
@pytest.mark.parametrize("mode", ["none", "gate", "guided"])
@pytest.mark.parametrize("hybrid", [False, True])
def test_solver_training_and_input_only_gradients(norm, mode, hybrid):
    solver, batch = make_solver(norm, mode, hybrid)
    for param in solver.model.parameters():
        param.grad = torch.full_like(param, 7.)
    initial_gradients = [p.grad.clone() for p in solver.model.parameters()]
    original_batch = [value.clone() for value in (batch.reference, batch.positive, batch.negative)]
    attacked = solver._generate_adversarial_reference(batch)
    assert not attacked.requires_grad
    for parameter, gradient in zip(solver.model.parameters(), initial_gradients):
        assert torch.equal(parameter.grad, gradient)
    assert solver.model.training
    if hybrid:
        with torch.no_grad():
            predictions = solver._inference(batch)
            expected = sum(solver.criterion(p.reference, p.positive, p.negative)[0] for p in predictions)
            assert torch.allclose(solver._attack_loss(batch), expected)
    before = [p.clone() for p in solver.model.parameters()]
    stats = solver.step(batch)
    assert np.isfinite(stats["adv_train_loss"])
    assert len(solver.history) == 1
    assert solver.log["adv_norm_max"] == [stats["adv_norm_max"]]
    assert any(not torch.equal(a, b) for a, b in zip(before, solver.model.parameters()))
    for previous, current in zip(original_batch, (batch.reference, batch.positive, batch.negative)):
        assert torch.equal(previous, current)
    if mode != "none":
        assert stats["adv_svd_drift_max"] <= solver.adv_svd_tau


def test_attack_freezes_batchnorm_and_restores_modes_on_error():
    solver, batch = make_solver("l2", "guided", batchnorm=True)
    bn = solver.model[1]
    solver.model[0].eval()
    saved = copy.deepcopy(solver.model.state_dict())
    solver._generate_adversarial_reference(batch)
    assert bn.training and not solver.model[0].training
    for key, value in saved.items():
        assert torch.equal(value, solver.model.state_dict()[key])
    def fail(_):
        raise RuntimeError("intentional")
    solver._attack_loss = fail
    with pytest.raises(RuntimeError, match="intentional"):
        solver._generate_adversarial_reference(batch)
    assert solver.model.training and bn.training and not solver.model[0].training


@pytest.mark.parametrize("mode", ["gate", "guided"])
@pytest.mark.parametrize("norm", ["l2", "linf"])
@pytest.mark.parametrize("hybrid", [False, True])
def test_sklearn_fit_and_configuration_forwarding(mode, norm, hybrid):
    rng = np.random.default_rng(12)
    model = cebra.CEBRA(model_architecture="offset10-model", device="cpu",
                        batch_size=16, max_iterations=1, num_hidden_units=8,
                        output_dimension=4, hybrid=hybrid, training_mode="adversarial",
                        attack_norm=norm, adv_svd_mode=mode, adv_svd_tau=0.03,
                        adv_svd_weight=2., adv_epsilon_factors=(0.5, 1.),
                        adv_steps=2, adv_svd_backtracks=3, adv_svd_eta=1e-7)
    cloned = clone(model)
    assert cloned.get_params() == model.get_params()
    data = rng.normal(size=(100, 4)).astype("float32")
    labels = rng.normal(size=(100, 2)).astype("float32")
    model.fit(data, labels)
    assert model.solver_.adv_svd_mode == mode
    assert model.solver_.adv_epsilon_factors == (0.5, 1.)
    assert model.solver_.adv_svd_weight == 2.
    assert model.solver_.last_attack_stats["adv_svd_drift_max"] <= 0.03
    assert np.isfinite(model.transform(data)).all()


def test_checkpoint_restores_attack_settings_and_accepts_legacy():
    solver, batch = make_solver("l2", "guided")
    solver.step(batch)
    state = solver.state_dict()
    restored, _ = make_solver("linf", "none")
    restored.load_state_dict(state)
    assert restored._attack_settings() == solver._attack_settings()
    legacy = {key: value for key, value in state.items() if key != "attack_settings"}
    restored.load_state_dict(legacy, strict=True)


def test_unsupported_batch_fails_before_optimizer_update():
    solver, _ = make_solver("l2", "gate")
    before = copy.deepcopy(solver.model.state_dict())
    with pytest.raises(ValueError, match="mini-batches"):
        solver.step(cebra.data.Batch(torch.arange(8), torch.arange(8), torch.arange(8)))
    with pytest.raises(ValueError, match="single-session"):
        solver.step([])
    for key, value in before.items():
        assert torch.equal(value, solver.model.state_dict()[key])


def test_sklearn_save_load_and_adapt(tmp_path):
    rng = np.random.default_rng(9)
    data = rng.normal(size=(80, 4)).astype("float32")
    labels = rng.normal(size=(80, 2)).astype("float32")
    model = cebra.CEBRA(model_architecture="offset10-model", device="cpu",
                        batch_size=8, max_iterations=1, max_adapt_iterations=1,
                        num_hidden_units=8, output_dimension=4,
                        training_mode="adversarial", attack_norm="l2", adv_steps=1,
                        adv_svd_mode="guided", adv_svd_tau=0.02,
                        adv_svd_weight=3., adv_epsilon_factors=(0.25, 1.))
    model.fit(data, labels)
    path = tmp_path / "svd-model.pt"
    model.save(path, backend="sklearn")
    restored = cebra.CEBRA.load(path, backend="sklearn", weights_only=False)
    assert restored.solver_._attack_settings() == model.solver_._attack_settings()
    np.testing.assert_allclose(restored.transform(data), model.transform(data))
    new_data = rng.normal(size=(80, 5)).astype("float32")
    model.fit(new_data, labels, adapt=True)
    assert model.solver_.adv_svd_mode == "guided"
    assert model.solver_.adv_svd_weight == 3.
    assert model.solver_.adv_epsilon_factors == (0.25, 1.)
    assert model.solver_.last_attack_stats["adv_svd_drift_max"] <= 0.02
