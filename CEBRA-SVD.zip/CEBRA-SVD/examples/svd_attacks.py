"""Run all four SVD variants on synthetic data, or on your own NumPy arrays.

From the project root after installation:
    python examples/svd_attacks.py --iterations 2
    python examples/svd_attacks.py --x neural.npy --y behavior.npy --iterations 1000
    python examples/svd_attacks.py --adaptive --hybrid

Synthetic examples check execution only; they do not measure scientific robustness.
"""

import argparse
import json

import numpy as np
import torch

import cebra


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--x", help="Neural array: time x neurons, .npy")
    parser.add_argument("--y", help="Behavior array: time x labels, .npy")
    parser.add_argument("--iterations", type=int, default=2)
    parser.add_argument("--device", default="cpu")
    parser.add_argument("--adaptive", action="store_true")
    parser.add_argument("--hybrid", action="store_true")
    parser.add_argument("--epsilon", type=float, help="Defaults to 2 for counts, 0.1 otherwise")
    parser.add_argument("--alpha", type=float, default=0.02)
    parser.add_argument("--tau", type=float, default=0.05)
    parser.add_argument("--weight", type=float, default=1.0)
    parser.add_argument("--rate-tau", type=float, help="Optional relative firing-rate bound")
    parser.add_argument("--loss-budget", type=int, help="Optional scalar loss-call cap per attack")
    parser.add_argument("--domain", choices=["continuous", "nonnegative", "counts"],
                        default="continuous")
    parser.add_argument("--raw-svd", action="store_true", help="Disable temporal mean centering")
    args = parser.parse_args()
    if args.epsilon is None:
        args.epsilon = 2. if args.domain == "counts" else 0.1
    if bool(args.x) != bool(args.y):
        parser.error("Provide --x and --y together.")
    if args.iterations <= 0:
        parser.error("--iterations must be positive.")
    torch.set_num_threads(1)
    if args.x:
        x, y = np.load(args.x, allow_pickle=False), np.load(args.y, allow_pickle=False)
    else:
        rng = np.random.default_rng(7)
        y = rng.normal(size=(400, 2)).astype("float32")
        x = y @ rng.normal(size=(2, 12)) + rng.normal(size=(400, 12)) * 0.2
        if args.domain == "counts":
            x = rng.poisson(np.exp(x.clip(-2, 2)))
        elif args.domain == "nonnegative":
            x = np.abs(x)
    x = x.astype("float32")
    results = {}
    for mode in ("gate", "guided"):
        for norm in ("l2", "linf"):
            torch.manual_seed(7)
            np.random.seed(7)
            model = cebra.CEBRA(
                model_architecture="offset10-model", device=args.device,
                batch_size=32, max_iterations=args.iterations, output_dimension=4,
                num_hidden_units=16, hybrid=args.hybrid, training_mode="adversarial",
                attack_norm=norm, adv_svd_mode=mode,
                adv_epsilon=args.epsilon, adv_alpha=args.alpha, adv_steps=4,
                adv_svd_tau=args.tau, adv_svd_weight=args.weight,
                adv_svd_center=not args.raw_svd, adv_input_domain=args.domain,
                adv_rate_tau=args.rate_tau, adv_max_loss_evaluations=args.loss_budget,
                adv_epsilon_factors=(0.25, 0.5, 1.) if args.adaptive else (1.,),
            )
            model.fit(x, y)
            results[f"{mode}_{norm}"] = model.solver_.last_attack_stats
    print(json.dumps(results, indent=2))


if __name__ == "__main__":
    main()
