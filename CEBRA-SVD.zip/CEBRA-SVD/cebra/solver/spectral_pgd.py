"""Reference-only PGD with optional per-window singular-value constraints.

The loss callback must return a scalar to maximize. Batch members can interact
through InfoNCE, so best-candidate selection always keeps a *whole batch*.
"""

from dataclasses import dataclass, field
import math
import time
from typing import Callable, Optional, Tuple

import torch


@dataclass(frozen=True)
class PGDConfig:
    epsilon: float = 0.05
    alpha: float = 0.01
    steps: int = 10
    norm: str = "linf"
    svd_mode: str = "none"
    svd_tau: float = 0.05
    svd_weight: float = 1.0
    svd_center: bool = True
    epsilon_factors: Tuple[float, ...] = (1.0,)
    backtracks: int = 8
    svd_eta: float = 1e-8
    input_domain: str = "continuous"
    best_iterate: bool = False
    rate_tau: Optional[float] = None
    rate_weight: float = 1.0
    discrete_candidates: int = 16
    discrete_max_edits: int = 8
    discrete_fallback: bool = True
    max_loss_evaluations: Optional[int] = None
    max_gradient_evaluations: Optional[int] = None

    def __post_init__(self):
        if self.norm not in ("l2", "linf"):
            raise ValueError("attack_norm must be 'l2' or 'linf'.")
        if self.svd_mode not in ("none", "gate", "guided"):
            raise ValueError("adv_svd_mode must be 'none', 'gate', or 'guided'.")
        if self.input_domain not in ("continuous", "nonnegative", "counts"):
            raise ValueError("adv_input_domain must be continuous, nonnegative, or counts.")
        for name in ("epsilon", "alpha", "svd_tau", "svd_weight", "svd_eta", "rate_weight"):
            value = getattr(self, name)
            if not isinstance(value, (int, float)) or not math.isfinite(value) or value < 0:
                raise ValueError(f"{name} must be finite and nonnegative.")
        if self.svd_eta == 0:
            raise ValueError("svd_eta must be strictly positive.")
        if not isinstance(self.svd_center, bool):
            raise ValueError("adv_svd_center must be a bool.")
        for name in ("best_iterate", "discrete_fallback"):
            if not isinstance(getattr(self, name), bool):
                raise ValueError(f"{name} must be a bool.")
        if self.rate_tau is not None and (not isinstance(self.rate_tau, (int, float)) or
                                          not math.isfinite(self.rate_tau) or self.rate_tau < 0):
            raise ValueError("rate_tau must be None or finite and nonnegative.")
        for name in ("discrete_candidates", "discrete_max_edits", "max_loss_evaluations",
                     "max_gradient_evaluations"):
            value = getattr(self, name)
            if value is None and name.startswith("max_"):
                continue
            if not isinstance(value, int) or isinstance(value, bool) or value < 1:
                raise ValueError(f"{name} must be a positive integer (or None for limits).")
        for name in ("steps", "backtracks"):
            if not isinstance(getattr(self, name), int) or getattr(self, name) < 0:
                raise ValueError(f"{name} must be a nonnegative integer.")
        factors = self.epsilon_factors
        if not isinstance(factors, (tuple, list)) or not factors:
            raise ValueError("adv_epsilon_factors must be a nonempty tuple or list.")
        if any(not isinstance(f, (int, float)) or not math.isfinite(f) or
               not 0 < f <= 1 for f in factors):
            raise ValueError("Each epsilon factor must be in (0, 1].")
        if any(a >= b for a, b in zip(factors, factors[1:])):
            raise ValueError("adv_epsilon_factors must be strictly increasing.")
        if self.svd_mode == "none" and not self.best_iterate and tuple(factors) != (1.0,):
            raise ValueError("Budget scans require a spectral method or best_iterate=True.")

    def validate_reference(self, reference):
        if (not isinstance(reference, torch.Tensor) or reference.ndim != 3 or
                not reference.is_floating_point()):
            raise ValueError("PGD requires floating (batch, neurons, time) references; "
                             "use single-session mini-batches (batch_size set).")
        if any(size == 0 for size in reference.shape) or not torch.isfinite(reference).all():
            raise ValueError("PGD references must be nonempty and finite.")
        if self.svd_mode != "none" and self.svd_center and reference.shape[-1] < 2:
            raise ValueError("Centered SVD needs at least two time bins. Use a temporal "
                             "model or explicitly set adv_svd_center=False.")
        if self.input_domain != "continuous" and (reference < 0).any():
            raise ValueError("Nonnegative/counts mode requires nonnegative references.")
        if self.input_domain == "counts" and not torch.equal(reference, reference.round()):
            raise ValueError("Counts mode requires integer-valued raw counts in a float tensor.")


@dataclass
class PGDResult:
    reference: torch.Tensor
    drift: torch.Tensor
    perturbation_norm: torch.Tensor
    epsilon: float
    loss: float
    clean_loss: float
    loss_evaluations: int
    backtracking_trials: int
    diagnostics: dict = field(default_factory=dict)


def singular_values(x: torch.Tensor, center: bool = True) -> torch.Tensor:
    """SVD over neurons x time, independently for every batch member.

    Half/bfloat16 inputs are promoted for SVD, including under autocast.
    Centering removes each neuron's temporal mean; it does not constrain rates.
    """
    with torch.autocast(device_type=x.device.type, enabled=False):
        matrix = x if x.dtype == torch.float64 else x.float()
        if center:
            matrix = matrix - matrix.mean(dim=-1, keepdim=True)
        return torch.linalg.svdvals(matrix)


def spectral_drift(x: torch.Tensor, clean_spectrum: torch.Tensor,
                   center: bool = True, eta: float = 1e-8) -> torch.Tensor:
    """Relative L2 distance of the full, sorted singular-value vector."""
    values = singular_values(x, center)
    return ((values - clean_spectrum).norm(dim=-1) /
            (clean_spectrum.norm(dim=-1) + eta))


def firing_rate_drift(x: torch.Tensor, clean_mean: torch.Tensor,
                      eta: float = 1e-8) -> torch.Tensor:
    """Relative L2 distance between per-neuron temporal means, per reference."""
    matrix = x if x.dtype == torch.float64 else x.float()
    return ((matrix.mean(dim=-1) - clean_mean).norm(dim=-1) /
            (clean_mean.norm(dim=-1) + eta))


def perturbation_norm(delta: torch.Tensor, norm: str) -> torch.Tensor:
    flat = delta.reshape(delta.shape[0], -1)
    return flat.norm(p=2, dim=1) if norm == "l2" else flat.abs().amax(dim=1)


def _broadcast(vector, reference):
    return vector.reshape(-1, *([1] * (reference.ndim - 1)))


def _normalize_l2(value):
    length = perturbation_norm(value, "l2").clamp_min(torch.finfo(value.dtype).tiny)
    return value / _broadcast(length, value)


def _project(candidate, original, epsilon, config):
    delta = candidate - original
    if config.norm == "linf":
        delta = delta.clamp(-epsilon, epsilon)
    else:
        length = perturbation_norm(delta, "l2").clamp_min(torch.finfo(delta.dtype).tiny)
        delta = delta * _broadcast((epsilon / length).clamp(max=1), delta)
    if config.input_domain == "counts":
        raise ValueError("Counts use explicit discrete edits, not continuous projection.")
    candidate = original + delta
    if config.input_domain != "continuous":
        candidate = candidate.clamp_min(0)
    return candidate


def generate_pgd(reference: torch.Tensor, loss_fn: Callable, config: PGDConfig) -> PGDResult:
    """Input-only attack with explicit discrete search and measured compute.

    Continuous inputs use random-start PGD. Counts use gradient-ranked +/-1
    edits and adaptive multi-edit candidates, never truncation or fractional
    backtracking. With fallback enabled and no exhausted evaluation budget,
    failure to move certifies only that no improving *single edit* was found
    in the entire +/-1 neighborhood of the current batch under the callback.
    It does not certify robustness to multi-edit attacks.

    Spectral methods and PGD-best keep the highest unpenalized-loss feasible
    whole batch observed. Plain PGD returns its final iterate. The callback
    must be deterministic (caller controls eval/train state) and scalar.
    """
    config.validate_reference(reference)
    if reference.is_cuda:
        torch.cuda.synchronize(reference.device)
    started = time.perf_counter()
    original = reference.detach().clone().contiguous()
    constrained = config.svd_mode != "none"
    use_best = constrained or config.best_iterate
    bounded = constrained or config.rate_tau is not None
    counters = dict(loss_evaluations=0, gradient_evaluations=0, svd_calls=0,
                    svd_evaluations=0, backtracking_trials=0, candidate_evaluations=0,
                    svd_checked=0, svd_rejected=0, rate_checked=0, rate_rejected=0,
                    discrete_exhaustive_sweeps=0, discrete_incomplete_searches=0)

    def values(x):
        counters["svd_calls"] += 1
        counters["svd_evaluations"] += len(x)
        return singular_values(x, config.svd_center)

    with torch.no_grad():
        clean_spectrum = values(original)
        precise_original = original if original.dtype == torch.float64 else original.float()
        clean_mean = precise_original.mean(dim=-1)

    def drift(x, indices=None):
        anchor = clean_spectrum if indices is None else clean_spectrum[indices]
        return (values(x) - anchor).norm(dim=-1) / (anchor.norm(dim=-1) + config.svd_eta)

    def rate(x, indices=None):
        anchor = clean_mean if indices is None else clean_mean[indices]
        return firing_rate_drift(x, anchor, config.svd_eta)

    def can_evaluate(number=1):
        return (config.max_loss_evaluations is None or
                counters["loss_evaluations"] + number <= config.max_loss_evaluations)

    def can_differentiate():
        return (config.max_gradient_evaluations is None or
                counters["gradient_evaluations"] < config.max_gradient_evaluations)

    def evaluate(x):
        if not can_evaluate():
            raise RuntimeError("Internal error: attack evaluation budget exceeded.")
        counters["loss_evaluations"] += 1
        value = loss_fn(x)
        if value.ndim != 0 or not torch.isfinite(value):
            raise FloatingPointError("Attack loss must be a finite scalar.")
        return value

    @torch.no_grad()
    def constraint_mask(candidate, selected):
        # Count only changed, unresolved reference-candidate checks. Accepted
        # references are not counted repeatedly in later backtracking rounds.
        valid = torch.ones(original.shape[0], device=original.device, dtype=torch.bool)
        if not selected.any():
            return valid
        subset = candidate[selected]
        if constrained:
            distance = drift(subset, selected)
            ok = torch.isfinite(distance) & (distance <= config.svd_tau)
            counters["svd_checked"] += int(selected.sum())
            counters["svd_rejected"] += int((~ok).sum())
            valid[selected] &= ok
        if config.rate_tau is not None:
            distance = rate(subset, selected)
            ok = torch.isfinite(distance) & (distance <= config.rate_tau)
            counters["rate_checked"] += int(selected.sum())
            counters["rate_rejected"] += int((~ok).sum())
            valid[selected] &= ok
        return valid

    @torch.no_grad()
    def feasible_step(current, proposed, epsilon):
        if not bounded:
            counters["candidate_evaluations"] += 1
            return _project(proposed, original, epsilon, config)
        accepted = torch.zeros(original.shape[0], device=original.device, dtype=torch.bool)
        result = current.clone()
        for attempt in range(config.backtracks + 1):
            candidate = _project(current + (proposed - current) * (0.5 ** attempt),
                                 original, epsilon, config)
            changed = (candidate != current).flatten(1).any(1)
            selected = ~accepted & changed
            valid = constraint_mask(candidate, selected)
            take = valid & ~accepted
            result = torch.where(_broadcast(take, result), candidate, result)
            accepted |= valid
            counters["backtracking_trials"] += 1
            counters["candidate_evaluations"] += 1
            if accepted.all():
                break
        return result

    @torch.no_grad()
    def discrete_step(current, gradient, epsilon, current_score):
        """Choose best observed improving whole-batch candidate; exact unit edits."""
        flat_gradient = gradient.flatten()
        size = flat_gradient.numel()
        # Both directions are included, even with zero/incorrect local gradient.
        # Stable ordering makes tied-gradient exhaustive regression tests reproducible.
        ranking = torch.argsort(torch.cat((flat_gradient, -flat_gradient)),
                                descending=True, stable=True).tolist()
        best_candidate, best_score = current, current_score
        visited = set()
        budget_interrupted = False

        def consider(edits):
            nonlocal best_candidate, best_score, budget_interrupted
            if not can_evaluate():
                budget_interrupted = True
                return
            candidate = current.clone()
            flat = candidate.view(-1)
            for signed_index in edits:
                coordinate = signed_index % size
                flat[coordinate] += 1 if signed_index < size else -1
            counters["candidate_evaluations"] += 1
            # Reject illegal integer edits directly. No projection/truncation.
            if (candidate < 0).any():
                return
            if (perturbation_norm(candidate - original, config.norm) > epsilon).any():
                return
            changed = (candidate != current).flatten(1).any(1)
            if not constraint_mask(candidate, changed).all():
                return
            score = float(evaluate(candidate))
            if score > best_score:
                best_candidate, best_score = candidate, score

        shortlist = ranking[:config.discrete_candidates]
        for edit in shortlist:
            consider([edit])
            visited.add(edit)
            if budget_interrupted:
                break

        # Grow a coherent set of distinct, gradient-preferred unit edits.
        # A rejected large group never prevents checking its singleton members.
        group = []
        used_coordinates = set()
        for edit in ranking:
            coordinate = edit % size
            if coordinate in used_coordinates:
                continue
            if edit >= size and current.view(-1)[coordinate] == 0:
                continue
            used_coordinates.add(coordinate)
            group.append(edit)
            length = len(group)
            if length >= 2 and (length & (length - 1) == 0 or length == config.discrete_max_edits):
                consider(group)
            if length >= config.discrete_max_edits or budget_interrupted:
                break

        if best_score <= current_score:
            if config.discrete_fallback and not budget_interrupted:
                counters["discrete_exhaustive_sweeps"] += 1
                # Stop at the first improving remaining singleton. If none
                # improves, every signed coordinate has actually been checked.
                for edit in ranking:
                    if edit not in visited:
                        consider([edit])
                    if best_score > current_score or budget_interrupted:
                        break
            else:
                budget_interrupted = True
        if budget_interrupted:
            counters["discrete_incomplete_searches"] += 1
        return best_candidate, best_score

    with torch.no_grad():
        clean_loss = float(evaluate(original))
    best, best_loss, best_epsilon = original.clone(), clean_loss, 0.0
    current, current_score, current_epsilon = original.clone(), clean_loss, 0.0

    def remember(candidate, score, epsilon):
        nonlocal best, best_loss, best_epsilon
        if score > best_loss:
            best, best_loss, best_epsilon = candidate.clone(), score, epsilon

    if config.epsilon > 0 and config.steps > 0:
        for factor in config.epsilon_factors:
            epsilon = config.epsilon * factor
            if not can_evaluate(2) or not can_differentiate():
                break
            if config.input_domain == "counts" and epsilon < 1:
                continue
            current = best.clone() if use_best else original.clone()
            current_score = best_loss if use_best else clean_loss
            current_epsilon = epsilon
            if config.input_domain != "counts":
                if config.norm == "linf":
                    noise = torch.empty_like(original).uniform_(-epsilon, epsilon)
                else:
                    noise = _normalize_l2(torch.randn_like(original))
                    radius = torch.rand(original.shape[0], device=original.device, dtype=original.dtype)
                    noise *= _broadcast(radius * epsilon, original)
                current = feasible_step(current, original + noise, epsilon)
                with torch.no_grad():
                    current_score = float(evaluate(current))
                    remember(current, current_score, epsilon)

            for _ in range(config.steps):
                # Reserve a loss evaluation for scoring the resulting candidate.
                if not can_evaluate(2) or not can_differentiate():
                    break
                with torch.enable_grad():
                    variable = current.detach().requires_grad_(True)
                    objective = evaluate(variable)
                    if config.svd_mode == "guided":
                        if config.svd_weight > 0:
                            objective = objective - config.svd_weight * drift(variable).square().mean()
                        if config.rate_tau is not None and config.rate_weight > 0:
                            objective = objective - config.rate_weight * rate(variable).square().mean()
                    gradient, = torch.autograd.grad(objective, variable)
                    counters["gradient_evaluations"] += 1
                if not torch.isfinite(gradient).all():
                    raise FloatingPointError("Nonfinite PGD gradient; inspect data/loss scale.")
                with torch.no_grad():
                    if config.input_domain == "counts":
                        candidate, score = discrete_step(current, gradient, epsilon, current_score)
                    else:
                        direction = gradient.sign() if config.norm == "linf" else _normalize_l2(gradient)
                        candidate = feasible_step(current, current + config.alpha * direction, epsilon)
                        score = float(evaluate(candidate))
                    unchanged = torch.equal(candidate, current)
                    current, current_score = candidate, score
                    remember(current, current_score, epsilon)
                    if unchanged:
                        break
        if not use_best:
            best, best_loss, best_epsilon = current, current_score, current_epsilon

    with torch.no_grad():
        final_drift = drift(best)
        final_rate = rate(best)
        delta = best - original
        final_norm = perturbation_norm(delta, config.norm)
        changed_bins = delta != 0
        diagnostics = dict(
            svd_rejection_rate=counters["svd_rejected"] / max(counters["svd_checked"], 1),
            svd_candidate_reference_checks=counters["svd_checked"],
            svd_rejected_reference_checks=counters["svd_rejected"],
            rate_rejection_rate=counters["rate_rejected"] / max(counters["rate_checked"], 1),
            svd_active_fraction=float((final_drift >= 0.9 * config.svd_tau).float().mean()) if constrained else 0.,
            unchanged_reference_fraction=float((~changed_bins.flatten(1).any(1)).float().mean()),
            attack_loss_gain=best_loss - clean_loss,
            changed_bin_count=int(changed_bins.sum()),
            effective_svd_drift=float(final_drift.mean()),
            firing_rate_drift_mean=float(final_rate.mean()),
            firing_rate_drift_max=float(final_rate.max()),
            gradient_evaluations=counters["gradient_evaluations"],
            svd_evaluations=counters["svd_evaluations"], svd_calls=counters["svd_calls"],
            candidate_evaluations=counters["candidate_evaluations"],
            discrete_exhaustive_sweeps=counters["discrete_exhaustive_sweeps"],
            discrete_incomplete_searches=counters["discrete_incomplete_searches"],
            loss_budget_exhausted=int(not can_evaluate(2)),
            gradient_budget_exhausted=int(not can_differentiate()),
        )
        if config.input_domain == "counts":
            diagnostics["spike_edit_count"] = int(delta.abs().sum())
            diagnostics["spikes_added"] = int(delta.clamp_min(0).sum())
            diagnostics["spikes_removed"] = int((-delta).clamp_min(0).sum())
    if reference.is_cuda:
        torch.cuda.synchronize(reference.device)
    diagnostics["attack_wall_time_seconds"] = time.perf_counter() - started
    return PGDResult(best.detach(), final_drift.detach(), final_norm.detach(),
                     best_epsilon, best_loss, clean_loss, counters["loss_evaluations"],
                     counters["backtracking_trials"], diagnostics)
