# SVD-constrained reference attacks — revision 2

This revision addresses the supplied code review while retaining local SVD,
`gate` and `guided`, and both L2/Linf budgets. Start with
[SVD_ATTACKS_FA.md](SVD_ATTACKS_FA.md) for the Persian guide, or
[REVIEW_RESPONSE.md](REVIEW_RESPONSE.md) for the issue-by-issue response.

## Methods and installation

```bash
python -m pip install -e .
python examples/svd_attacks.py --iterations 2
python examples/svd_attacks.py --domain counts --iterations 1 --loss-budget 32
python -m pytest tests/test_spectral_pgd.py tests/test_spectral_review.py tests/test_solver.py -q
```

| Method | `adv_svd_mode` | `adv_best_iterate` | Selection |
| --- | --- | --- | --- |
| PGD | `"none"` | `False` | Last iterate |
| PGD-best | `"none"` | `True` | Best observed loss, including clean |
| SVD gate (A) | `"gate"` | Either | Best feasible observed loss |
| SVD guided (B) | `"guided"` | Either | Best feasible observed loss |

Each supports `attack_norm="l2"` or `"linf"`. L2 covers **all neurons and
bins of each reference**, not one budget per neuron. Linf bounds every entry.
All attacks perturb only `batch.reference`. Candidate selection keeps whole
batches because InfoNCE can couple samples.

```python
import cebra

model = cebra.CEBRA(
    model_architecture="offset10-model", batch_size=512,
    max_iterations=1000, training_mode="adversarial",
    attack_norm="l2", adv_svd_mode="guided",
    adv_epsilon=0.1, adv_alpha=0.02, adv_steps=10,
    adv_svd_tau=0.05, adv_svd_weight=1.0,
    adv_svd_center=True, adv_rate_tau=None,
    adv_epsilon_factors=(1.0,),
)
model.fit(X_train, behavior_train)  # X_train: time x neurons
print(model.solver_.last_attack_stats)
```

These numerical values are examples, not calibrated neural-data settings.
Hybrid training, adaptation, sklearn cloning, and save/load preserve the options.
Supported training: single-session mini-batches, including `hybrid=True`.
Full-batch index-based and multi-session list-based adversarial training are
rejected before an optimizer update. Old solver checkpoints without the new
settings remain loadable.

## Spectral and firing-rate definitions

For each `X_b` of shape `neurons x time`, default centering subtracts every
neuron's temporal mean. The full sorted singular-value vector is compared:

```
Xc = X - mean(X, time)
D_svd = ||svdvals(Xc_adv) - svdvals(Xc)||_2 / (||svdvals(Xc)||_2 + eta)
mu = mean(X, time)
D_rate = ||mu_adv - mu||_2 / (||mu||_2 + eta)
```

The hard conditions apply to **each reference**, not the batch average:

```
||X_adv - X||_p <= tested_epsilon <= adv_epsilon
D_svd <= adv_svd_tau                       # gate/guided only
D_rate <= adv_rate_tau                     # if not None, any attack mode
```

| Spectral ablation | Parameters |
| --- | --- |
| Centered SVD | `adv_svd_center=True, adv_rate_tau=None` |
| Raw SVD | `adv_svd_center=False, adv_rate_tau=None` |
| Centered SVD + mean-rate bound | `adv_svd_center=True, adv_rate_tau=0.05` |

The rate bound is on the vector of per-neuron means; it is not a separate
relative bound for each neuron. Centered SVD alone is intentionally insensitive
to constant per-neuron shifts. Raw SVD can be dominated by mean firing rates.
Keep these as separate ablations rather than silently changing the constraint.

Guided maximizes:

```
contrastive_loss - adv_svd_weight * mean(D_svd**2)
                 - adv_rate_weight * mean(D_rate**2)  # only if rate bound enabled
```

The negative sign is deliberate. The penalties affect the **attack direction**,
not the encoder's outer training objective. Actual candidate acceptance uses
the hard bounds, and final best-candidate scoring uses unpenalized attack loss.
With SVD weight zero and no rate bound, guided matches gate for the same seed.

Centered SVD needs at least two time bins. Use a temporal architecture such as
`offset10-model`, or explicitly request raw SVD for `offset1-model`. A centered
N x 10 window has rank at most min(N,9); it is not a reliable estimate of full
recording dimensionality by assumption. Raw N x 1 SVD only measures one value.
Half/bfloat16 SVD inputs are promoted to float32; float64 is preserved.

## Continuous search and PGD-best fairness

Continuous proposals use the normalized gradient for L2, the sign gradient for
Linf, and norm-ball projection. If a spectral/rate bound is enabled, violating
references undergo candidate-checked step halving; exhausted references keep
their last feasible value. This is a heuristic, not exact projection onto the
nonconvex spectral feasible set. It can miss stronger attacks.

PGD and PGD-best evaluate the **same unpenalized random start and intermediate
iterates**, using the same gradient and score-evaluation schedule; only return
selection differs. PGD-best therefore isolates the effect of best-iterate
selection. Gate/guided can perform additional SVD/backtracking work and can stop
at different times; report measured cost, not just the configured step count.

Optional `adv_epsilon_factors=(0.25, 0.5, 1.0)` scans increasing fractions of
`adv_epsilon`, with up to `adv_steps` per factor. It is supported by SVD methods
and PGD-best. Ordinary final-iterate PGD uses `(1.0,)`. Budgets are enumerated,
not binary-searched; no monotonic drift assumption is made. The chosen budget
is for the whole selected batch; actual per-reference norms may be smaller.

## Discrete spike-count search: no truncation/backtracking

Use `adv_input_domain="counts"` for raw, integer-valued, nonnegative counts
stored in a floating tensor. `continuous` and `nonnegative` remain available.

For counts, each search step:

1. Computes an input gradient (guided includes enabled penalties).
2. Ranks **both +1 and -1** unit edits by their first-order gain.
3. Tests a shortlist of signed coordinates, plus growing sets of distinct
   coordinates of sizes 2, 4, ... up to `adv_discrete_max_edits`.
4. Rejects illegal integer candidates directly using nonnegativity, the
   per-reference norm budget, the SVD bound, and any rate bound. No fractional
   edit, rounding, truncation, or continuous backtracking is used.
5. Evaluates actual loss for valid candidates and keeps the best **improving**
   whole batch observed.
6. If the shortlist/groups yield no improvement and fallback is enabled, scans
   all remaining signed single-coordinate edits until an improvement is found
   or the entire neighborhood is exhausted.

With no exhausted compute cap, fallback finds an improving feasible unit edit
if one exists at the current batch, even when its local gradient is zero or
misleading. This is a **local singleton-search** property, not a global attack
optimality guarantee. Multi-edit moves can improve where singletons do not;
only the configured groups are tested. The fallback can be expensive.

`adv_alpha` only controls continuous PGD. Count edits have an exact unit size;
use `adv_discrete_candidates`, `adv_discrete_max_edits`, `adv_steps`, and epsilon
to control count search. Epsilon below 1 permits no nonzero count edit under
L2 or Linf, so the output is clean. Count search starts clean and is deterministic;
its greedy improving trajectory makes last/best selection equivalent on that
trajectory. Best-iterate ablation is primarily informative for continuous PGD.

Disable fallback or set compute limits only with awareness that an unchanged
reference then says nothing about whether an improving singleton exists.
`discrete_incomplete_searches` and budget flags expose interrupted searches.
Even a complete singleton search does not certify robustness.

## Configuration and logging

| New/revised setting | Default | Meaning |
| --- | --- | --- |
| `adv_best_iterate` | `False` | Enable PGD-best when mode is none |
| `adv_rate_tau` | `None` | Optional hard bound on relative mean-rate drift |
| `adv_rate_weight` | `1.0` | Guided rate penalty if the bound is enabled |
| `adv_discrete_candidates` | `16` | Initial signed-unit-edit shortlist |
| `adv_discrete_max_edits` | `8` | Largest adaptive distinct-coordinate group |
| `adv_discrete_fallback` | `True` | Remaining-singleton scan when shortlist stalls |
| `adv_max_loss_evaluations` | `None` | Hard total scalar callback budget per attack |
| `adv_max_gradient_evaluations` | `None` | Hard gradient budget across all epsilon factors |
| `adv_svd_tau` | `0.05` | Per-reference relative spectrum bound |
| `adv_svd_weight` | `1.0` | Guided SVD penalty |
| `adv_svd_center` | `True` | Temporal centering per neuron |
| `adv_svd_backtracks` | `8` | Maximum continuous step halvings |
| `adv_svd_eta` | `1e-8` | Positive denominator stabilizer |
| `adv_epsilon_factors` | `(1.0,)` | Fixed-budget default |

All options also exist on solvers; low-level `PGDConfig` uses names without the
`adv_` prefix (and `norm`, `epsilon_factors`, `backtracks`, etc.).

`solver.last_attack_stats` and `solver.log` include:

| Metric | Exact interpretation |
| --- | --- |
| `svd_rejection_rate` | Rejected / evaluated changed-reference SVD checks, including retries |
| `svd_candidate_reference_checks`, `svd_rejected_reference_checks` | Denominator and numerator; references already accepted are not recounted in later backtracking |
| `svd_active_fraction` | Fraction of final references with drift >= 0.9*tau; zero for no SVD constraint |
| `unchanged_reference_fraction` | Fraction with exactly zero final perturbation |
| `attack_loss_gain` | Selected raw attack loss minus clean loss |
| `spike_edit_count`, `spikes_added`, `spikes_removed` | Final net count edits, counts mode only; not cumulative search actions |
| `changed_bin_count` | Number of changed neuron-time cells in the whole batch |
| `effective_svd_drift` | Mean final accepted drift; max also in `adv_svd_drift_max` |
| `firing_rate_drift_mean`, `firing_rate_drift_max`, `rate_rejection_rate` | Mean-rate diagnostics |
| `adv_norm_max`, `adv_norm_mean` | Actual perturbation norms |
| `adv_epsilon_selected` | Budget associated with the selected whole batch; zero for clean fallback |
| `adv_loss_evaluations` | Scalar callbacks, including gradient forwards, clean, random-start, and candidate scoring |
| `gradient_evaluations` | Actual input-gradient calculations |
| `svd_evaluations`, `svd_calls` | Number of matrices decomposed and vectorized calls, including clean/final diagnostics |
| `candidate_evaluations`, `adv_backtracking_trials` | Proposed-candidate checks and continuous feasibility rounds |
| `discrete_exhaustive_sweeps`, `discrete_incomplete_searches` | Fallback usage and truncated count searches |
| `loss_budget_exhausted` | Insufficient remaining loss budget for another gradient+score pair |
| `gradient_budget_exhausted` | Gradient cap reached |
| `attack_wall_time_seconds` | Search time, CUDA-synchronized when applicable |
| `optimizer_updates` | 1 for clean training steps, 2 for adversarial steps |

Spectral drift is now measured for **all** baselines; no-SVD results no longer
report dummy zeros. SVD rejection is zero when no constraint is enforced.
Float32 norm measurements may exceed a budget by roundoff (around 1e-7 in tests).
Hard SVD/rate acceptance does not add tolerance to tau.

## Evaluation-only metrics and calibration

`cebra.solver.spectral_metrics` supplies:

- `structure_metrics(clean, attacked, ...)`: centered/raw SVD, mean-rate drift,
  relative Frobenius covariance distance, normalized principal-subspace projector
  distance, RMS lagged autocorrelation change, and block-Hankel SVD drift.
- `context_spectral_drift(clean_window, attacked_window, clean_context, start=...)`:
  insert the local attack into a supplied longer context. It verifies the exact
  clean slice. It does not change the encoder architecture or attack constraint.
- `calibrate_thresholds(train_reference, train_matched, quantile=0.95, ...)`:
  estimate SVD/rate thresholds from matched **training-only** windows.

Principal-subspace distance is NaN, with an explicit validity mask, when rank
or a tied singular-value cutoff makes that subspace unidentifiable. Lag and
Hankel delay are explicit. These metrics are for analysis only, not extra terms
secretly added to the attack loss. They demonstrate why matching singular
values does not preserve eigenvectors, covariance, time order, or behavior.

Calibration requires comparable behavioral states and appropriate within-trial
windows. The helper cannot infer train/test provenance. The ablation runner
uses nearest-behavior train pairs with overlapping windows excluded; it saves
both centered and raw calibrations. Check pair quality and rejection/activity
logs: a train-pair quantile may be much too permissive for the attack budget.
Calibration is an experimental choice, not a physiological validity guarantee.

## Controlled ablations and independent decoding evaluation

```bash
python examples/svd_ablation.py --seeds 0 1 2 --taus 0.01 0.05 \
  --norms l2 linf --spectra centered raw centered-rate \
  --iterations 1000 --loss-budget 32 --gradient-budget 5 \
  --data split_data.npz --output experiment_results
```

NPZ keys: `X_train`, `y_train`, `X_test`, `y_test`; optional `trial_train`,
`trial_test` identify trial boundaries. X is time x neurons; y is continuous
behavior. Splits must be supplied explicitly. No window crosses splits, and
provided trial boundaries are respected. Discrete labels need a separate
classification decoder/evaluation protocol; this runner is a regression example.

The runner uses CEBRA's model, InfoNCE, and solver with a precomputed nearest-
behavior positive-sampling schedule, rather than sklearn's stochastic loader.
It stores schedule hashes, uses identical initialization and batches for each
seed, and resets attack RNG each training step. This avoids confounding data
order with the different number of random draws used by attacks.

Methods include ordinary CEBRA (`standard`, one clean update),
`standard-matched` (two clean updates on the same batch), PGD, PGD-best, gate,
and guided (one clean + one adversarial update). Actual optimizer updates,
attack loss/gradient/SVD evaluations, and training wall time are recorded.
Caps match **upper budgets**, not necessarily realized compute or wall time.
Counter sums refer to inner attack search; training wall time includes outer
training updates as well. Offline structural diagnostics are separate.

A ridge decoder is fitted only on clean training embeddings and then frozen.
Held-out decoding is attacked by maximizing its prediction MSE, with **no SVD
or rate constraint**, under the same norm/domain budget. Continuous evaluation
uses multiple random starts; deterministic count evaluation runs once instead
of counting identical restarts as extra strength. The evaluation objective and
runs are separate from training's contrastive attack, but reuse the same search
engine; this is not independent-implementation verification or a robustness
certificate. Report both clean/attacked MSE and R2.

`--calibrate` replaces the fixed tau grid with the matching centered/raw train
quantile. It does not choose `rate_tau` automatically. Outputs include CSV/JSON
results, train-pair calibration data, and configuration/schedule metadata.

See `review_validation/` for the actual short synthetic runs and
`TEST_REPORT.md` for test results. Real-recording experiments, long training,
GPU validation, and a stronger independent attack suite remain necessary for
publication claims. Spectral gradient projection remains a future experiment,
as explicitly prioritized in the supplied review.

## Existing integration behavior retained

The clean-update then adversarial-update schedule remains. Search uses
`autograd.grad` on input only, freezes BN/dropout through eval mode, and restores
every module's original mode afterwards. Hybrid attacks use both behavior and
time losses for both norms. Clean logging and history remain consistent.
The original `base_2.py`/`base____.py` are inactive historical files; edits target
`base.py`. The previous optional-`trial_ids` indexing repair remains in place.
Reference windows are perturbed independently, not reconstructed into a single
consistent attacked recording. Neither SVD nor count validity alone guarantees
neural or behavioral validity.
