# راهنمای نسخهٔ دوم: اصلاحات نقد کد

چهار حالت اصلی `gate` و `guided` برای `l2` و `linf` حفظ شده‌اند؛ ε هم همچنان
بودجهٔ حمله است. راهنمای فنی کامل در `SVD_ATTACKS.md` و پاسخ بندبه‌بند نقد در
`REVIEW_RESPONSE.md` قرار دارد.

## اصلاح مهم count خام

در حالت `adv_input_domain="counts"` دیگر `trunc()` و نصف‌کردن گام نداریم.
گرادیان، مختصات نورون–زمان را رتبه‌بندی می‌کند؛ کاندیدهای صحیح `+1/-1` و
گروه‌های کوچک با تعداد ویرایش افزایشی ساخته می‌شوند. هر کاندید از نظر
نامنفی بودن، ε، SVD، قید نرخ اختیاری و **loss واقعی** بررسی می‌شود.

اگر فهرست اولیه هیچ بهبودی پیدا نکند، جست‌وجوی پشتیبان بقیهٔ ویرایش‌های
تک‌مختصاتی با هر دو علامت را بررسی می‌کند. بدون سقف محاسباتی، اگر یک
ویرایش تک‌اسپایکِ مجاز و بهبوددهنده در همسایگی فعلی وجود داشته باشد، این
مسیر آن را پیدا می‌کند. این تضمینِ محلی به معنی یافتن قوی‌ترین حمله یا
تمام ترکیب‌های چنداسپایکی نیست.

در این حالت اندازهٔ ویرایش دقیقاً یک اسپایک است؛ `adv_alpha` فقط برای PGD
پیوسته کاربرد دارد. ε کمتر از ۱ همچنان هیچ تغییر صحیح غیرصفری را مجاز نمی‌کند.

## نمونهٔ استفاده

```bash
python -m pip install -e .
```

```python
import cebra

model = cebra.CEBRA(
    model_architecture="offset10-model",
    batch_size=512,
    max_iterations=1000,
    training_mode="adversarial",
    attack_norm="l2",                # یا linf
    adv_svd_mode="guided",           # یا gate
    adv_input_domain="counts",       # برای count خام صحیح و نامنفی
    adv_epsilon=2.0,
    adv_steps=10,
    adv_svd_tau=0.05,
    adv_svd_center=True,
    adv_rate_tau=0.05,                # None: غیرفعال
    adv_discrete_candidates=16,
    adv_discrete_max_edits=8,
    adv_discrete_fallback=True,
)
model.fit(X_train, behavior_train)
print(model.solver_.last_attack_stats)
```

اعداد بالا صرفاً نمونه‌اند. برای دادهٔ استانداردشده/پیوسته از
`adv_input_domain="continuous"` استفاده کن و ε و `adv_alpha` را متناسب با
مقیاس داده انتخاب کن. برای نرخ پیوستهٔ نامنفی حالت `nonnegative` وجود دارد.

## سه حالت SVD و نرخ firing

| حالت | تنظیمات |
| --- | --- |
| SVD مرکززدایی‌شده | `adv_svd_center=True, adv_rate_tau=None` |
| SVD خام | `adv_svd_center=False, adv_rate_tau=None` |
| SVD مرکززدایی‌شده + قید میانگین نرخ | `adv_svd_center=True, adv_rate_tau=0.05` |

قید نرخ، فاصلهٔ نسبی بردار میانگین زمانی نورون‌ها را برای هر Reference می‌سنجد.
در `guided`، اگر قید نرخ فعال باشد، جریمهٔ آن هم وارد جهت گرادیان می‌شود؛
وزنش با `adv_rate_weight` قابل تنظیم است. تغییرات ثابت firing rate دیگر در
حالت سوم فقط به خاطر مرکززدایی از بررسی پنهان نمی‌مانند.

رتبهٔ SVD مرکززدایی‌شده در پنجرهٔ ۱۰bin حداکثر ۹ است. Local SVD حفظ شده؛
Hankel و پنجرهٔ بلندتر فعلاً ابزار ارزیابی‌اند، نه قید تازه در هدف حمله.

## baseline منصفانه‌تر

| روش | تنظیمات |
| --- | --- |
| PGD آخرین گام | `adv_svd_mode="none", adv_best_iterate=False` |
| PGD بهترین گام | `adv_svd_mode="none", adv_best_iterate=True` |
| SVD gate | `adv_svd_mode="gate"` |
| SVD guided | `adv_svd_mode="guided"` |

همه با هر دو norm قابل اجرا هستند. PGD و PGD-best مسیر و برنامهٔ ارزیابی
یکسان دارند؛ تفاوتشان انتخاب خروجی است. در count خام، مسیر جست‌وجو فقط
حرکت بهبوددهنده را قبول می‌کند و بنابراین آخرین و بهترین گام آن مسیر یکی است.

جست‌وجوی چند بودجه با `adv_epsilon_factors=(0.25, 0.5, 1.0)` برای روش‌های
SVD و PGD-best در دسترس است. پیش‌فرض `(1.0,)` بودجه را ثابت نگه می‌دارد.

## لاگ‌هایی که اضافه شده‌اند

- `svd_rejection_rate`: نسبت بررسی‌های ردشده به علت SVD، شامل تلاش‌های مجدد.
- `svd_active_fraction`: سهم Referenceهای نهایی با drift حداقل ۹۰٪ آستانه.
- `unchanged_reference_fraction`: سهم Referenceهای کاملاً بدون تغییر.
- `attack_loss_gain`: اختلاف loss کاندید نهایی و دادهٔ تمیز.
- `spike_edit_count`: مجموع اسپایک‌های اضافه/حذف‌شده در خروجی نهایی.
- `changed_bin_count`: تعداد خانه‌های نورون–زمان تغییرکرده.
- `effective_svd_drift` و `adv_svd_drift_max`: میانگین و بیشینهٔ drift نهایی.
- `firing_rate_drift_max`: بیشترین تغییر نسبی بردار نرخ میانگین.
- `gradient_evaluations`، `adv_loss_evaluations` و `svd_evaluations`: هزینهٔ واقعی جست‌وجو.
- `attack_wall_time_seconds` و `optimizer_updates`: زمان حمله و تعداد آپدیت‌ها.

برای کنترل هزینه می‌توان `adv_max_loss_evaluations` و
`adv_max_gradient_evaluations` گذاشت. این سقف‌ها روی تمام بودجه‌های ε یک
حمله مشترک‌اند. با اتمام سقف، جست‌وجو ممکن است کامل نباشد؛
`discrete_incomplete_searches` و پرچم‌های اتمام بودجه این موضوع را ثبت می‌کنند.
خاموش‌کردن `adv_discrete_fallback` هم تضمین بررسی تک‌ویرایش‌ها را حذف می‌کند.

## ارزیابی ساختار و کالیبراسیون

ماژول `cebra/solver/spectral_metrics.py` این ابزارها را دارد:

- فاصلهٔ زیرفضای اصلی، فاصلهٔ covariance، drift خودهمبستگی زمانی و نرخ firing.
- Hankel-SVD و SVD روی context بلندتری که صریحاً به تابع داده می‌شود.
- `calibrate_thresholds` برای صدک تغییرات جفت‌پنجره‌های مشابه در **Train**.

برای زیرفضایی که به علت رتبهٔ ناکافی یا مقدارهای singular تکراری قابل
تشخیص نیست، خروجی `NaN` و ماسک اعتبار داده می‌شود؛ عدد دلخواه گزارش نمی‌شود.
معیارهای زمانی و زیرفضایی صرفاً برای تحلیل‌اند و به loss اصلی اضافه نشده‌اند.
کالیبراسیون τ تضمین اعتبار فیزیولوژیکی نیست؛ کیفیت جفت‌پنجره‌ها و لاگ فعالیت
قید را باید بررسی کرد. دادهٔ Test نباید برای تنظیم τ استفاده شود.

## اجرای ablation

```bash
python examples/svd_ablation.py \
  --iterations 1000 --seeds 0 1 2 --taus 0.01 0.05 \
  --norms l2 linf --spectra centered raw centered-rate \
  --loss-budget 32 --gradient-budget 5 \
  --data split_data.npz --output experiment_results
```

فایل NPZ باید `X_train`, `y_train`, `X_test`, `y_test` داشته باشد.
متغیر y در این مثال رفتار پیوسته است. برای جلوگیری از عبور پنجره‌ها از
مرز trial، `trial_train` و `trial_test` هم می‌توانی بدهی. تقسیم Train/Test
باید از قبل مشخص باشد. بدون `--data`، اسکریپت دادهٔ مصنوعی می‌سازد.

این ابزار وزن اولیه و ترتیب batchها را بین روش‌ها ثابت نگه می‌دارد و
تعداد آپدیت‌ها را ثبت می‌کند. علاوه بر CEBRA معمولی با یک آپدیت، baseline
`standard-matched` با دو آپدیت clean دارد تا با یک clean + یک adversarial
از نظر تعداد آپدیت مقایسه شود. سقف یکسان به معنی زمان اجرای یکسان نیست؛
هزینهٔ واقعی هم در CSV/JSON ذخیره می‌شود.

decoder از نوع Ridge فقط روی embeddingهای Train آموزش می‌بیند. سپس برای
ارزیابی روی Test، حمله‌ای با هدف افزایش خطای decoding و بدون قید SVD/rate
اجرا می‌شود. هدف و اجرای این ارزیابی از حملهٔ کنتراستیِ آموزش جداست، اما
موتور جست‌وجو مشترک است؛ گواهی robustness یا تأیید یک پیاده‌سازی مستقل نیست.

خروجی ۴۴ اجرای کوتاه مصنوعی در `review_validation/` قرار دارد. این اجراها
صرفاً صحت مسیر آزمایش را بررسی می‌کنند. در بعضی تنظیمات، τ کالیبره‌شده
آن‌قدر آزاد بود که SVD هیچ کاندیدی را رد نکرد؛ همین نکته در لاگ دیده می‌شود.
برتری یک روش روی recording واقعی هنوز اثبات نشده است.

نتیجهٔ تست‌ها و محدودیت‌ها در `TEST_REPORT.md` آمده است.
