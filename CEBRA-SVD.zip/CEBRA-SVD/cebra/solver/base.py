#
# CEBRA: Consistent EmBeddings of high-dimensional Recordings using Auxiliary variables
# © Mackenzie W. Mathis & Steffen Schneider (v0.4.0+)
# Source code:
# https://github.com/AdaptiveMotorControlLab/CEBRA
#
# Please see LICENSE.md for the full license document:
# https://github.com/AdaptiveMotorControlLab/CEBRA/blob/main/LICENSE.md
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
# http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
#
"""This package contains abstract base classes for different solvers.

Solvers are used to package models, criterions and optimizers and implement training
loops. When subclassing abstract solvers, in the simplest case only the
:py:meth:`Solver._inference` needs to be overridden.

For more complex use cases, the :py:meth:`Solver.step` and
:py:meth:`Solver.fit` method can be overridden to
implement larger changes to the training loop.
"""

import abc
import copy
from contextlib import contextmanager
import os
from typing import Callable, Dict, List, Literal, Optional

import literate_dataclasses as dataclasses
# ----------------------------------------------------------------------
# Helpers
# ----------------------------------------------------------------------
import torch

import cebra
import cebra.data
import cebra.io
import cebra.models
from cebra.solver.spectral_pgd import PGDConfig, generate_pgd
from cebra.solver.util import Meter
from cebra.solver.util import ProgressBar


def _l2_normalize(t: torch.Tensor, eps: float = 1e-12):
    """Per-sample L2 normalisation (zero vectors stay zero)."""
    flat = t.reshape(t.size(0), -1)
    norm = flat.norm(p=2, dim=1, keepdim=True).clamp(min=eps)
    return t / norm.view(-1, *([1] * (t.dim() - 1)))


def _rand_radius_like(t: torch.Tensor):
    """U(0,1) radius shaped like t but broadcastable (B,1,1,…) ."""
    return torch.rand([t.size(0)] + [1] * (t.dim() - 1), device=t.device)


def _proj_l2_ball(adv: torch.Tensor, orig: torch.Tensor, epsilon: float):
    """Project adv back to the closed L2 ball of radius ε around orig."""
    delta = adv - orig
    flat = delta.reshape(delta.size(0), -1)
    norm = flat.norm(p=2, dim=1, keepdim=True).clamp(min=1e-12)
    factor = torch.where(norm > epsilon, norm / epsilon, torch.ones_like(norm))
    delta = delta / factor.view(-1, *([1] * (delta.dim() - 1)))
    return orig + delta


#

# positive_perm= shuffle_and_permute(batch.positive)
# anchor_perm= shuffle_and_permute(batch.reference)
# negative_perm= shuffle_and_permute(batch.negative)


# copied_data = copy.deepcopy(batch)#batch.clone().detach()
# copied_data.positive = torch.randn_like(batch.positive).cuda() #positive_perm
# copied_data.reference = torch.randn_like(batch.reference).cuda() #anchor_perm
# copied_data.negative = torch.randn_like(batch.negative).cuda() #negative_perm


# prediction_fix = self._inference(batch)

# prediction_perm= self._inference(copied_data)

# x_perm_ = torch.cat([prediction_perm.reference,prediction_perm.positive, prediction_perm.negative], dim=0)
# x_fix= torch.cat([prediction_fix.reference,prediction_fix.positive, prediction_fix.negative], dim=0)

# self.optimizer.zero_grad()

# cos_raw    = torch.nn.functional.cosine_similarity(x_perm_,x_fix)
# L_cos      = torch.log((2 + cos_raw) / 2).mean()  # log version
# # print(L_cos.item())
# L_cos.backward()
# self.optimizer.step()


# fake_data=torch.randn_like(batch.positive).cuda()


# self.optimizer.zero_grad()

# positive_perm= shuffle_and_permute(batch.positive)
# anchor_perm= shuffle_and_permute(batch.reference)
# fake_data=torch.randn_like(batch.positive).cuda()


# x_perm_ = torch.cat([anchor_perm,positive_perm, batch.negative], dim=0)

# idx = torch.randperm(x_perm_.size(0))[:positive_perm.size(0)]


# permed_data_negative   = x_perm_[idx]

# fake_batch = cebra.data.Batch(
#                 reference=batch.reference,
#                 positive=batch.positive,
#                 negative=batch.negative
#             )
# fake_prediction = self._inference(fake_batch)
# loss, align, uniform= self.criterion(fake_prediction.reference,
#                                       fake_prediction.positive,
#                                       fake_prediction.negative)
# loss.backward()
# self.optimizer.step()


def clone_batch(batch):
    # 1) shallow-copy the Batch container
    new_batch = copy.copy(batch)

    # 2) for each tensor attribute in the batch, clone & detach
    #    adjust this list to match the actual fields in your Batch
    tensor_fields = ['reference', 'positive', 'negative', 'anchor', 'other_tensor']
    for field in tensor_fields:
        tensor = getattr(batch, field, None)
        if isinstance(tensor, torch.Tensor):
            # clone and detach so it shares neither data nor grad
            setattr(new_batch, field, tensor.clone().detach())
        # if the field can be a list/tuple of tensors, you could also do:
        # elif (isinstance(tensor, (list, tuple)) and
        #       all(isinstance(t, torch.Tensor) for t in tensor)):
        #     cloned = [t.clone().detach() for t in tensor]
        #     setattr(new_batch, field, type(tensor)(cloned))

    return new_batch


def shuffle_and_permute(data: torch.Tensor) -> torch.Tensor:
    """
    Shuffle the second (M) and third (D) dimensions of a 3D tensor independently.

    Parameters:
        data (torch.Tensor): Input tensor of shape [N, M, D].

    Returns:
        torch.Tensor: Tensor with shuffled M and D dimensions.
    """
    N, M, D = data.size()

    # Create random permutations for the second and third dimensions
    perm_M = torch.randperm(M)
    # perm_D = torch.randperm(D)

    # Permute the second dimension (axis=1) first, then the third dimension (axis=2)
    shuffled_data = data[:, perm_M.cuda(), :]

    return shuffled_data


@dataclasses.dataclass
class Solver(abc.ABC, cebra.io.HasDevice):
    """Solver base class.

    A solver contains helper methods for bundling a model, criterion and optimizer.

    Attributes:
        model: The encoder for transforming reference, positive and negative samples.
        criterion: The criterion computed from the similarities between positive pairs
            and negative pairs. The criterion can have trainable parameters on its own.
        optimizer: A PyTorch optimizer for updating model and criterion parameters.
        history: Deprecated since 0.0.2. Use :py:attr:`log`.
        decode_history: Deprecated since 0.0.2. Use a hook during training for validation and
            decoding. See the arguments of :py:meth:`fit`.
        log: The logs recorded during training, typically contains the ``total`` loss as well
            as the logs for positive (``pos``) and negative (``neg``) pairs. For the standard
            criterions in CEBRA, also contains the value of the ``temperature``.
        tqdm_on: Use ``tqdm`` for showing a progress bar during training.
        training_mode: The training mode, either "clean" or "adversarial".
        adv_epsilon: The maximum perturbation allowed for adversarial training.
        adv_alpha: The step size for adversarial training.
        adv_steps: The number of steps for adversarial training.
        attack_norm: The norm used for adversarial training, either "l2" or "linf".
        adv_svd_mode: "none", "gate" (A), or "guided" (B). See SVD_ATTACKS.md.
        adv_svd_tau: Maximum relative singular-value drift for each reference.
        adv_svd_weight: Weight of the squared-drift penalty in the guided attack.
        adv_svd_center: Subtract each neuron's time mean before SVD.
        adv_epsilon_factors: Increasing fractions of adv_epsilon to test.
        adv_svd_backtracks: Maximum halvings for a spectrally infeasible proposal.
        adv_svd_eta: Positive stabilizer for the relative spectral distance.
        adv_input_domain: "continuous", "nonnegative", or integer-valued "counts".
        adv_best_iterate: Enable the PGD-best baseline when SVD mode is "none".
        adv_rate_tau: Optional hard bound on relative mean-rate drift.
        adv_rate_weight: Guided rate penalty weight when the rate bound is enabled.
        adv_discrete_candidates: Size of the signed-unit-edit shortlist.
        adv_discrete_max_edits: Largest adaptive group of distinct unit edits.
        adv_discrete_fallback: Scan remaining unit edits if the shortlist stalls.
        adv_max_loss_evaluations: Optional hard scalar callback cap per attack.
        adv_max_gradient_evaluations: Optional hard gradient cap per attack.
    """

    model: torch.nn.Module
    criterion: torch.nn.Module
    optimizer: torch.optim.Optimizer
    history: List = dataclasses.field(default_factory=list)
    decode_history: List = dataclasses.field(default_factory=list)
    log: Dict = dataclasses.field(default_factory=lambda: ({
        "pos": [],
        "neg": [],
        "total": [],
        "temperature": []
    }))
    tqdm_on: bool = True
    training_mode: str = "clean"
    adv_epsilon: float = 0.05
    adv_alpha: float = 0.01
    adv_steps: int = 10
    attack_norm: str = "linf"
    adv_svd_mode: str = "none"
    adv_svd_tau: float = 0.05
    adv_svd_weight: float = 1.0
    adv_svd_center: bool = True
    adv_epsilon_factors: tuple = (1.0,)
    adv_svd_backtracks: int = 8
    adv_svd_eta: float = 1e-8
    adv_input_domain: str = "continuous"
    adv_best_iterate: bool = False
    adv_rate_tau: Optional[float] = None
    adv_rate_weight: float = 1.0
    adv_discrete_candidates: int = 16
    adv_discrete_max_edits: int = 8
    adv_discrete_fallback: bool = True
    adv_max_loss_evaluations: Optional[int] = None
    adv_max_gradient_evaluations: Optional[int] = None

    def __post_init__(self):
        cebra.io.HasDevice.__init__(self)
        self.best_loss = float("inf")
        self._pgd_config()  # Validate configuration at construction.
        self.last_attack_stats = {}

    def _pgd_config(self):
        return PGDConfig(
            epsilon=self.adv_epsilon, alpha=self.adv_alpha, steps=self.adv_steps,
            norm=self.attack_norm, svd_mode=self.adv_svd_mode,
            svd_tau=self.adv_svd_tau, svd_weight=self.adv_svd_weight,
            svd_center=self.adv_svd_center, epsilon_factors=self.adv_epsilon_factors,
            backtracks=self.adv_svd_backtracks, svd_eta=self.adv_svd_eta,
            input_domain=self.adv_input_domain,
            best_iterate=self.adv_best_iterate, rate_tau=self.adv_rate_tau,
            rate_weight=self.adv_rate_weight,
            discrete_candidates=self.adv_discrete_candidates,
            discrete_max_edits=self.adv_discrete_max_edits,
            discrete_fallback=self.adv_discrete_fallback,
            max_loss_evaluations=self.adv_max_loss_evaluations,
            max_gradient_evaluations=self.adv_max_gradient_evaluations,
        )

    def _attack_settings(self):
        names = ("training_mode", "attack_norm", "adv_epsilon", "adv_alpha",
                 "adv_steps", "adv_svd_mode", "adv_svd_tau", "adv_svd_weight",
                 "adv_svd_center", "adv_epsilon_factors", "adv_svd_backtracks",
                 "adv_svd_eta", "adv_input_domain", "adv_best_iterate",
                 "adv_rate_tau", "adv_rate_weight", "adv_discrete_candidates",
                 "adv_discrete_max_edits", "adv_discrete_fallback",
                 "adv_max_loss_evaluations", "adv_max_gradient_evaluations")
        return {name: getattr(self, name) for name in names}

    def _validate_attack_batch(self, batch):
        if not isinstance(batch, cebra.data.Batch):
            raise ValueError("Adversarial training supports single-session mini-batches only.")
        self._pgd_config().validate_reference(batch.reference)

    @staticmethod
    def _replace_reference(batch, reference):
        return cebra.data.Batch(reference, batch.positive, batch.negative,
                                index=batch.index, index_reversed=batch.index_reversed)

    def _attack_loss(self, batch):
        prediction = self._inference(batch)
        return self.criterion(prediction.reference, prediction.positive,
                              prediction.negative)[0]

    @contextmanager
    def _attack_eval_mode(self):
        # Freeze dropout/BN state during candidate search and restore every
        # module's mode, including deliberately frozen submodules, afterwards.
        roots = [self.model, self.criterion]
        reference_model = getattr(self, "reference_model", None)
        if reference_model is not None:
            roots.append(reference_model)
        modes = {module: module.training for root in roots for module in root.modules()}
        try:
            for root in roots:
                root.eval()
            yield
        finally:
            for module, training in modes.items():
                module.training = training

    def _generate_adversarial_reference(self, batch):
        self._validate_attack_batch(batch)
        batch.to(self.device)
        with self._attack_eval_mode():
            result = generate_pgd(
                batch.reference,
                lambda reference: self._attack_loss(self._replace_reference(batch, reference)),
                self._pgd_config(),
            )
        self.last_attack_stats = dict(
            adv_loss=result.loss,
            adv_clean_loss=result.clean_loss,
            adv_norm_max=result.perturbation_norm.max().item(),
            adv_norm_mean=result.perturbation_norm.mean().item(),
            adv_epsilon_selected=result.epsilon,
            adv_loss_evaluations=result.loss_evaluations,
            adv_backtracking_trials=result.backtracking_trials,
        )
        self.last_attack_stats.update(
            adv_svd_drift_max=result.drift.max().item(),
            adv_svd_drift_mean=result.drift.mean().item(),
        )
        self.last_attack_stats.update(result.diagnostics)
        return result.reference

    def _adversarial_update(self, batch):
        self.optimizer.zero_grad()
        reference = self._generate_adversarial_reference(batch)
        self.optimizer.zero_grad()
        loss = self._attack_loss(self._replace_reference(batch, reference))
        loss.backward()
        self.optimizer.step()
        self.last_attack_stats["adv_train_loss"] = loss.item()

    def state_dict(self) -> dict:
        """Return a dictionary fully describing the current solver state.

        Returns:
            State dictionary, including the state dictionary of the models and
            optimizer. Also contains the training history and the CEBRA version
            the model was trained with.
        """

        return {
            "model": self.model.state_dict(),
            "optimizer": self.optimizer.state_dict(),
            "loss": torch.tensor(self.history),
            "decode": self.decode_history,
            "criterion": self.criterion.state_dict(),
            "version": cebra.__version__,
            "log": self.log,
            "attack_settings": self._attack_settings(),
        }

    def load_state_dict(self, state_dict: dict, strict: bool = True):
        """Update the solver state with the given state_dict.

        Args:
            state_dict: Dictionary with parameters for the `model`, `optimizer`,
                and the past loss history for the solver.
            strict: Make sure all states can be loaded. Set to `False` to allow
                to partially load the state for all given keys.
        """

        def _contains(key):
            if key in state_dict:
                return True
            elif strict:
                raise KeyError(
                    f"Key {key} missing in state_dict. Contains: {list(state_dict.keys())}."
                )
            return False

        def _get(key):
            return state_dict.get(key)

        # Optional for backward compatibility with old checkpoints.
        if "attack_settings" in state_dict:
            for name in self._attack_settings():
                if name in state_dict["attack_settings"]:
                    setattr(self, name, state_dict["attack_settings"][name])
            self._pgd_config()
        if _contains("model"):
            self.model.load_state_dict(_get("model"))
        if _contains("criterion"):
            self.criterion.load_state_dict(_get("criterion"))
        if _contains("optimizer"):
            self.optimizer.load_state_dict(_get("optimizer"))
        # TODO(stes): This will be deprecated at some point; the "log" attribute
        # holds the same information.
        if _contains("loss"):
            self.history = _get("loss").cpu().numpy().tolist()
        if _contains("decode"):
            self.decode_history = _get("decode")
        if _contains("log"):
            self.log = _get("log")

    @property
    def num_parameters(self) -> int:
        """Total number of parameters in the encoder and criterion."""
        return sum(p.numel() for p in self.parameters())

    def parameters(self):
        """Iterate over all parameters."""
        for parameter in self.model.parameters():
            yield parameter

        for parameter in self.criterion.parameters():
            yield parameter

    def _get_loader(self, loader):
        return ProgressBar(
            loader,
            "tqdm" if self.tqdm_on else "off",
        )

    def fit(
            self,
            loader: cebra.data.Loader,
            valid_loader: cebra.data.Loader = None,
            *,
            save_frequency: int = None,
            valid_frequency: int = None,
            decode: bool = False,
            logdir: str = None,
            save_hook: Callable[[int, "Solver"], None] = None,
    ):
        """Train model for the specified number of steps.

        Args:
            loader: Data loader, which is an iterator over `cebra.data.Batch` instances.
                Each batch contains reference, positive and negative input samples.
            valid_loader: Data loader used for validation of the model.
            save_frequency: If not `None`, the frequency for automatically saving model checkpoints
                to `logdir`.
            valid_frequency: The frequency for running validation on the ``valid_loader`` instance.
            logdir:  The logging directory for writing model checkpoints. The checkpoints
                can be read again using the `solver.load` function, or manually via loading the
                state dict.

        TODO:
            * Refine the API here. Drop the validation entirely, and implement this via a hook?
        """

        self.to(loader.device)

        iterator = self._get_loader(loader)
        self.model.train()
        for num_steps, batch in iterator:
            stats = self.step(batch)
            iterator.set_description(stats)

            if save_frequency is None:
                continue
            save_model = num_steps % save_frequency == 0
            run_validation = (valid_loader
                              is not None) and (num_steps % valid_frequency
                                                == 0)
            if run_validation:
                validation_loss = self.validation(valid_loader)
                if self.best_loss is None or validation_loss < self.best_loss:
                    self.best_loss = validation_loss
                    self.save(logdir, "checkpoint_best.pth")
            if save_model:
                if decode:
                    self.decode_history.append(
                        self.decoding(loader, valid_loader))
                if save_hook is not None:
                    save_hook(num_steps, self)
                if logdir is not None:
                    self.save(logdir, f"checkpoint_{num_steps:#07d}.pth")

    def step(self, batch: cebra.data.Batch) -> dict:
        """One clean update followed by an optional adversarial update.

        This retains the uploaded project's two-update training schedule.
        Standard log keys describe the clean update; ``adv_*`` keys describe
        candidate search and the final adversarial training loss.
        """
        if self.training_mode == "adversarial":
            self._validate_attack_batch(batch)
        self.optimizer.zero_grad()
        prediction = self._inference(batch)
        loss, align, uniform = self.criterion(
            prediction.reference, prediction.positive, prediction.negative)
        loss.backward()
        self.optimizer.step()
        stats = dict(pos=align.item(), neg=uniform.item(), total=loss.item(),
                     temperature=self.criterion.temperature)
        if self.training_mode == "adversarial":
            self._adversarial_update(batch)
            stats.update(self.last_attack_stats)
        stats["optimizer_updates"] = 2 if self.training_mode == "adversarial" else 1
        self.history.append(loss.item())
        for key, value in stats.items():
            self.log.setdefault(key, []).append(value)
        return stats

    def validation(self,
                   loader: cebra.data.Loader,
                   session_id: Optional[int] = None):
        """Compute score of the model on data.

        Args:
            loader: Data loader, which is an iterator over `cebra.data.Batch` instances.
                Each batch contains reference, positive and negative input samples.
            session_id: The session ID, an integer between 0 and the number of sessions in the
                multisession model, set to None for single session.

        Returns:
            Loss averaged over iterations on data batch.
        """
        assert (session_id is None) or (session_id == 0)
        iterator = self._get_loader(loader)
        total_loss = Meter()
        self.model.eval()
        for _, batch in iterator:
            prediction = self._inference(batch)
            loss, _, _ = self.criterion(prediction.reference,
                                        prediction.positive,
                                        prediction.negative)
            total_loss.add(loss.item())
        return total_loss.average

    @torch.no_grad()
    def decoding(self, train_loader, valid_loader):
        """Deprecated since 0.0.2."""
        train_x = self.transform(train_loader.dataset[torch.arange(
            len(train_loader.dataset.neural))])
        train_y = train_loader.dataset.index
        valid_x = self.transform(valid_loader.dataset[torch.arange(
            len(valid_loader.dataset.neural))])
        valid_y = valid_loader.dataset.index
        decode_metric = train_loader.dataset.decode(
            train_x.cpu().numpy(),
            train_y.cpu().numpy(),
            valid_x.cpu().numpy(),
            valid_y.cpu().numpy(),
        )
        return decode_metric

    @torch.no_grad()
    def transform(self, inputs: torch.Tensor) -> torch.Tensor:
        """Compute the embedding.

        This function by default only applies the ``forward`` function
        of the given model, after switching it into eval mode.

        Args:
            inputs: The input signal

        Returns:
            The output embedding.

        TODO:
            * Remove eval mode
        """

        self.model.eval()
        return self.model(inputs)

    @abc.abstractmethod
    def _inference(self, batch: cebra.data.Batch) -> cebra.data.Batch:
        """Given a batch of input examples, return the model outputs.

        TODO: make this a public function?

        Args:
            batch: The input data, not necessarily aligned across the batch
                dimension. This means that ``batch.index`` specifies the map
                between reference/positive samples, if not equal ``None``.

        Returns:
            Processed batch of data. While the input data might not be aligned
            across the sample dimensions, the output data should be aligned and
            ``batch.index`` should be set to ``None``.
        """
        raise NotImplementedError

    def load(self, logdir, filename="checkpoint.pth"):
        """Load the experiment from its checkpoint file.

        Args:
            filename (str): Checkpoint name for loading the experiment.
        """

        savepath = os.path.join(logdir, filename)
        if not os.path.exists(savepath):
            print("Did not find a previous experiment. Starting from scratch.")
            return
        checkpoint = torch.load(savepath, map_location=self.device)
        self.load_state_dict(checkpoint, strict=True)

    def save(self, logdir, filename="checkpoint_last.pth"):
        """Save the model and optimizer params.

        Args:
            logdir: Logging directory for this model.
            filename: Checkpoint name for saving the experiment.
        """
        if not os.path.exists(os.path.dirname(logdir)):
            os.makedirs(logdir)
        savepath = os.path.join(logdir, filename)
        torch.save(
            self.state_dict(),
            savepath,
        )


@dataclasses.dataclass
class MultiobjectiveSolver(Solver):
    """Train models to satisfy multiple learning objectives.

    This variant of the standard :py:class:`cebra.solver.base.Solver` implements multi-objective
    or "hybrid" training.

    Attributes:
        model: A multi-objective CEBRA model
        optimizer: The optimizer used for training.
        num_behavior_features: The feature dimension for the features dedicated
            to satisfy the behavior contrastive objective. The remainder is used
            for time contrastive learning.
        renormalize_features: If ``True``, normalize the behavior and time
            contrastive features individually before computing similarity scores.
    """

    num_behavior_features: int = 3
    renormalize_features: bool = False
    output_mode: Literal["overlapping", "separate"] = "overlapping"

    @property
    def num_time_features(self):
        return self.num_total_features - self.num_behavior_features

    @property
    def num_total_features(self):
        return self.model.num_output

    def __post_init__(self):
        super().__post_init__()
        self._check_dimensions()
        self.model = cebra.models.MultiobjectiveModel(
            self.model,
            dimensions=(self.num_behavior_features, self.model.num_output),
            renormalize=self.renormalize_features,
            output_mode=self.output_mode,
        )

    def _check_dimensions(self):
        """Check the feature dimensions for behavior/time contrastive learning.

        Raises:
            ValueError: If feature dimensions are larger than the model features,
                or not sufficiently large for renormalization.
        """
        if self.output_mode == "separate":
            if self.num_behavior_features >= self.num_total_features:
                raise ValueError(
                    "For multi-objective training, the number of features for "
                    f"behavior contrastive learning ({self.num_behavior_features}) cannot be as large or larger "
                    f"than the total feature dimension ({self.num_total_features})."
                )
            if self.num_time_features >= self.num_total_features:
                raise ValueError(
                    "For multi-objective training, the number of features for "
                    f"time contrastive learning ({self.num_time_features}) cannot be as large or larger "
                    f"than the total feature dimension ({self.num_total_features})."
                )
        if self.renormalize_features:
            if self.num_behavior_features < 2:
                raise ValueError(
                    "When renormalizing the features, the feature dimension needs "
                    "to be at least 2 for behavior. "
                    "Check the values of 'renormalize_features' and 'num_behavior_features'."
                )
            if self.num_time_features < 2:
                raise ValueError(
                    "When renormalizing the features, the feature dimension needs "
                    "to be at least 2 for behavior. "
                    "Check the values of 'renormalize_features' and 'num_time_features'."
                )

    def _attack_loss(self, batch):
        behavior, temporal = self._inference(batch)
        return (self.criterion(behavior.reference, behavior.positive, behavior.negative)[0] +
                self.criterion(temporal.reference, temporal.positive, temporal.negative)[0])

    def step(self, batch: cebra.data.Batch) -> dict:
        """Train both behavior and time objectives, including in either PGD norm."""
        if self.training_mode == "adversarial":
            self._validate_attack_batch(batch)
        self.optimizer.zero_grad()
        behavior, temporal = self._inference(batch)
        behavior_loss, behavior_align, behavior_uniform = self.criterion(
            behavior.reference, behavior.positive, behavior.negative)
        time_loss, time_align, time_uniform = self.criterion(
            temporal.reference, temporal.positive, temporal.negative)
        loss = behavior_loss + time_loss
        loss.backward()
        self.optimizer.step()
        stats = dict(
            behavior_pos=behavior_align.item(), behavior_neg=behavior_uniform.item(),
            behavior_total=behavior_loss.item(), time_pos=time_align.item(),
            time_neg=time_uniform.item(), time_total=time_loss.item(),
        )
        if self.training_mode == "adversarial":
            self._adversarial_update(batch)
            stats.update(self.last_attack_stats)
        stats["optimizer_updates"] = 2 if self.training_mode == "adversarial" else 1
        self.history.append(loss.item())
        for key, value in stats.items():
            self.log.setdefault(key, []).append(value)
        return stats
